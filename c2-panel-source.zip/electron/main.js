const { app, BrowserWindow, Menu, Tray, nativeImage, ipcMain, dialog } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');

let mainWindow;
let tray;
let serverProcess;
let serverStarted = false;

const isDev = process.env.NODE_ENV === 'development';
const PORT = process.env.PORT || 5000;

function getResourcePath(relativePath) {
  if (isDev) {
    return path.join(__dirname, '..', relativePath);
  }
  return path.join(process.resourcesPath, relativePath);
}

function registerIpcHandlers() {
  ipcMain.on('window-minimize', () => {
    if (mainWindow) mainWindow.minimize();
  });

  ipcMain.on('window-maximize', () => {
    if (mainWindow) {
      if (mainWindow.isMaximized()) {
        mainWindow.unmaximize();
      } else {
        mainWindow.maximize();
      }
    }
  });

  ipcMain.on('window-close', () => {
    if (mainWindow) mainWindow.close();
  });

  ipcMain.handle('get-version', () => {
    return app.getVersion();
  });

  ipcMain.handle('get-platform', () => {
    return process.platform;
  });
}

function createWindow() {
  const iconPath = isDev 
    ? path.join(__dirname, '../client/public/favicon.png')
    : path.join(process.resourcesPath, 'favicon.png');

  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    icon: iconPath,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: '#0a0a0a',
      symbolColor: '#00ff00',
      height: 40
    },
    backgroundColor: '#0a0a0a',
    show: false
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  if (isDev) {
    mainWindow.loadURL(`http://localhost:${PORT}`);
    mainWindow.webContents.openDevTools();
  } else {
    const indexPath = path.join(getResourcePath('dist/public'), 'index.html');
    
    if (fs.existsSync(indexPath)) {
      mainWindow.loadFile(indexPath);
    } else {
      mainWindow.loadURL(`http://localhost:${PORT}`);
    }
  }

  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
    console.error('Failed to load:', errorCode, errorDescription);
    if (!isDev && serverStarted) {
      setTimeout(() => {
        mainWindow.loadURL(`http://localhost:${PORT}`);
      }, 2000);
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.on('close', (event) => {
    if (tray && !app.isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}

function createTray() {
  const iconPath = isDev 
    ? path.join(__dirname, '../client/public/favicon.png')
    : path.join(process.resourcesPath, 'favicon.png');

  try {
    const icon = nativeImage.createFromPath(iconPath);
    tray = new Tray(icon.resize({ width: 16, height: 16 }));

    const contextMenu = Menu.buildFromTemplate([
      { label: 'Show Panel', click: () => {
        if (mainWindow) {
          mainWindow.show();
          mainWindow.focus();
        }
      }},
      { type: 'separator' },
      { label: 'Quit', click: () => {
        app.isQuitting = true;
        app.quit();
      }}
    ]);

    tray.setToolTip('C2 Panel');
    tray.setContextMenu(contextMenu);

    tray.on('double-click', () => {
      if (mainWindow) {
        mainWindow.show();
        mainWindow.focus();
      }
    });
  } catch (error) {
    console.error('Failed to create tray:', error);
  }
}

function startServer() {
  return new Promise((resolve, reject) => {
    const serverPath = getResourcePath('dist/index.cjs');
    
    if (!fs.existsSync(serverPath)) {
      console.error('Server file not found:', serverPath);
      reject(new Error(`Server file not found: ${serverPath}`));
      return;
    }

    console.log('Starting server from:', serverPath);

    serverProcess = spawn('node', [serverPath], {
      cwd: isDev ? path.join(__dirname, '..') : process.resourcesPath,
      env: {
        ...process.env,
        NODE_ENV: 'production',
        PORT: PORT.toString()
      },
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let resolved = false;

    serverProcess.stdout.on('data', (data) => {
      const output = data.toString();
      console.log(`Server: ${output}`);
      if (output.includes('serving on port') && !resolved) {
        resolved = true;
        serverStarted = true;
        resolve();
      }
    });

    serverProcess.stderr.on('data', (data) => {
      console.error(`Server Error: ${data}`);
    });

    serverProcess.on('error', (error) => {
      console.error('Failed to start server:', error);
      if (!resolved) {
        resolved = true;
        reject(error);
      }
    });

    serverProcess.on('exit', (code, signal) => {
      console.log(`Server exited with code ${code}, signal ${signal}`);
      serverStarted = false;
      if (!resolved) {
        resolved = true;
        reject(new Error(`Server exited unexpectedly with code ${code}`));
      }
    });

    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        console.log('Server startup timeout, proceeding anyway');
        resolve();
      }
    }, 10000);
  });
}

function killServer() {
  if (serverProcess) {
    try {
      serverProcess.kill('SIGTERM');
      setTimeout(() => {
        if (serverProcess && !serverProcess.killed) {
          serverProcess.kill('SIGKILL');
        }
      }, 3000);
    } catch (error) {
      console.error('Error killing server:', error);
    }
    serverProcess = null;
  }
}

app.whenReady().then(async () => {
  registerIpcHandlers();

  if (!isDev) {
    try {
      await startServer();
      console.log('Server started successfully');
    } catch (error) {
      console.error('Failed to start embedded server:', error);
      const choice = dialog.showMessageBoxSync({
        type: 'error',
        title: 'Server Error',
        message: 'Failed to start the embedded server. The application may not work correctly.',
        buttons: ['Continue Anyway', 'Quit'],
        defaultId: 0
      });
      if (choice === 1) {
        app.quit();
        return;
      }
    }
  }

  createWindow();
  createTray();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    killServer();
    app.quit();
  }
});

app.on('before-quit', () => {
  app.isQuitting = true;
  killServer();
  if (tray) {
    tray.destroy();
    tray = null;
  }
});

app.on('will-quit', () => {
  killServer();
});
