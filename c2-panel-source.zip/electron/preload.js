const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  isElectron: true,
  
  minimize: () => {
    ipcRenderer.send('window-minimize');
  },
  
  maximize: () => {
    ipcRenderer.send('window-maximize');
  },
  
  close: () => {
    ipcRenderer.send('window-close');
  },
  
  getVersion: () => {
    return ipcRenderer.invoke('get-version');
  },
  
  getPlatform: () => {
    return ipcRenderer.invoke('get-platform');
  }
});
