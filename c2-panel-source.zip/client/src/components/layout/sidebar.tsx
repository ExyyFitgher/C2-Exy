import { 
  ShieldAlert, 
  Activity, 
  Terminal, 
  Database, 
  Settings, 
  Users,
  Wifi,
  Lock,
  Monitor,
  Pickaxe,
  Keyboard,
  Camera
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";

export function Sidebar() {
  const [location] = useLocation();
  const items = [
    { icon: ShieldAlert, label: "Overview", href: "/", active: location === "/" },
    { icon: Settings, label: "Builder", href: "/builder", active: location === "/builder" },
    { icon: Users, label: "Targets", href: "/targets", active: location === "/targets" },
    { icon: Database, label: "Files", href: "/files", active: location === "/files" },
    { icon: Monitor, label: "Screen", href: "/screen", active: location === "/screen" },
    { icon: Keyboard, label: "Keylogger", href: "/keylogger", active: location === "/keylogger" },
    { icon: Camera, label: "Webcam", href: "/webcam", active: location === "/webcam" },
    { icon: Activity, label: "Processes", href: "/processes", active: location === "/processes" },
    { icon: Pickaxe, label: "Mining", href: "/mining", active: location === "/mining" },
    { icon: Terminal, label: "Console", href: "/console", active: location === "/console" },
    { icon: Wifi, label: "Network", href: "/network", active: location === "/network" },
    { icon: Lock, label: "Vault", href: "/vault", active: location === "/vault" },
  ];

  return (
    <div className="w-16 md:w-64 h-screen border-r border-primary/20 bg-black/90 flex flex-col backdrop-blur-md">
      <div className="p-6 border-b border-primary/20 flex items-center gap-3">
        <Activity className="text-primary w-6 h-6 animate-pulse" />
        <span className="hidden md:block font-display font-bold text-xl tracking-widest text-primary text-glow">
          EXY ATTACK
        </span>
      </div>

      <div className="flex-1 py-6 space-y-1">
        {items.map((item) => (
          <Link key={item.label} href={item.href}>
            <button
              className={cn(
                "w-full flex items-center gap-4 px-6 py-3 text-sm transition-all duration-200 group relative",
                item.active 
                  ? "text-primary bg-primary/10 border-r-2 border-primary" 
                  : "text-muted-foreground hover:text-primary hover:bg-primary/5"
              )}
            >
              <item.icon className={cn("w-5 h-5", item.active && "animate-pulse")} />
              <span className="hidden md:block font-mono uppercase tracking-wider">{item.label}</span>
              
              {item.active && (
                <div className="absolute inset-0 bg-gradient-to-r from-primary/0 to-primary/5 pointer-events-none" />
              )}
            </button>
          </Link>
        ))}
      </div>

      <div className="p-4 border-t border-primary/20">
        <div className="flex items-center gap-3 p-2 rounded border border-primary/10 bg-primary/5">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <div className="hidden md:block">
            <div className="text-[10px] text-primary/60 uppercase">System Status</div>
            <div className="text-xs font-bold text-primary">ONLINE - SECURE</div>
          </div>
        </div>
      </div>
    </div>
  );
}
