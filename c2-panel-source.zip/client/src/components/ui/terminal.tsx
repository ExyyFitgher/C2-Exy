import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

interface TerminalProps {
  className?: string;
  logs: string[];
}

export function Terminal({ className, logs }: TerminalProps) {
  return (
    <div className={cn("bg-black/80 border border-primary/30 p-4 font-mono text-xs h-full overflow-hidden flex flex-col", className)}>
      <div className="flex items-center gap-2 mb-2 border-b border-primary/20 pb-2">
        <div className="w-2 h-2 rounded-full bg-red-500" />
        <div className="w-2 h-2 rounded-full bg-yellow-500" />
        <div className="w-2 h-2 rounded-full bg-green-500" />
        <span className="ml-2 text-primary/50 text-[10px] uppercase">System.log</span>
      </div>
      <div className="flex-1 overflow-y-auto space-y-1 scrollbar-hide">
        {logs.map((log, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2 }}
            className="text-primary/80"
          >
            <span className="text-primary/40 mr-2">[{new Date().toLocaleTimeString()}]</span>
            {log}
          </motion.div>
        ))}
        <div className="animate-pulse text-primary">_</div>
      </div>
    </div>
  );
}
