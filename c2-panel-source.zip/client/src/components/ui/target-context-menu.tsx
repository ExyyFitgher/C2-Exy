import * as React from "react";
import { 
  ContextMenu, 
  ContextMenuContent, 
  ContextMenuItem, 
  ContextMenuTrigger,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubTrigger,
  ContextMenuSubContent,
  ContextMenuLabel,
} from "@/components/ui/context-menu";
import { 
  Terminal, Key, Cookie, CreditCard, Bitcoin, Camera, Mic, FileText, Wifi, Power,
  Eye, Download, Upload, Trash2, Skull, ShieldOff, Activity, Keyboard, MousePointer2,
  Globe, MessageSquare, HardDrive, Cpu, Network, Ghost, Save, Play, Database, Lock,
  Video, Gauge, ArrowUpDown, Signal, Route, Server, Smartphone, Tablet, Laptop,
  List, FileCode, TerminalSquare, Zap, CloudLightning, Radio, Share2, Search, Scan,
  AlertTriangle, History, Clipboard, Layers, Code, Command, Hash, Fingerprint,
  Bluetooth, Cast, Scissors, Copy, Disc, DollarSign, Wallet, FileJson, FileKey,
  ShieldAlert, Siren, UserX, UserCheck, RefreshCcw, PowerOff, LogOut, MonitorOff,
  Speaker, Image, Music, FileArchive, FolderOpen, Box, Settings, Sliders,
  Printer, Battery, Phone, Tv, Mail, Cloud, Shield
} from "lucide-react";

export function TargetContextMenu({ children, targetName = "Target" }: { children: React.ReactNode, targetName?: string }) {
  
  const logAction = (action: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    const event = new CustomEvent('hack-log', { 
      detail: { message: `[${targetName}] ${action}`, type } 
    });
    window.dispatchEvent(event);
  };

  return (
    <ContextMenu>
      <ContextMenuTrigger>{children}</ContextMenuTrigger>
      <ContextMenuContent className="w-80 bg-black/95 border border-primary/30 text-primary backdrop-blur-md font-mono max-h-[80vh] overflow-y-auto">
        <ContextMenuLabel className="text-xs text-primary/50 uppercase tracking-widest flex items-center justify-between sticky top-0 bg-black/95 z-10 pb-2 border-b border-primary/20 mb-2">
          <span>EXY ELITE OPS</span>
          <span className="text-[9px] bg-red-900/50 text-red-400 px-1 rounded animate-pulse">ROOT ACCESS</span>
        </ContextMenuLabel>
        
        {/* QUICK ACTIONS */}
        <ContextMenuItem onClick={() => logAction('Establishing Remote Shell connection...', 'success')} className="focus:bg-primary/20 cursor-pointer">
          <Terminal className="w-4 h-4 mr-2" /> Quick Shell (CMD)
        </ContextMenuItem>
        <ContextMenuItem onClick={() => logAction('Injecting Meterpreter payload...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
          <Zap className="w-4 h-4 mr-2" /> Inject Payload
        </ContextMenuItem>
        <ContextMenuItem onClick={() => logAction('Scanning for vulnerabilities...', 'info')} className="focus:bg-primary/20 cursor-pointer">
          <Scan className="w-4 h-4 mr-2" /> Quick Vuln Scan
        </ContextMenuItem>

        <ContextMenuSeparator className="bg-primary/20" />

        {/* NETWORK & CONNECTIVITY */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Gauge className="w-4 h-4 mr-2 text-cyan-400" /> Network Intelligence
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-64 bg-black/95 border border-primary/30 text-primary">
            <ContextMenuItem onClick={() => logAction('Running Speedtest... Result: DOWNLOAD: 145Mbps (FAST) | UPLOAD: 45Mbps', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Activity className="w-4 h-4 mr-2 text-green-400" /> Speed Analysis (Ookla)
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Ping Test: 24ms to Google DNS (Low Latency)', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Signal className="w-4 h-4 mr-2" /> Latency Check
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Scanning local subnet 192.168.1.0/24... Found 14 devices.', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Search className="w-4 h-4 mr-2" /> LAN Scanner
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Network Topology Map generated.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Share2 className="w-4 h-4 mr-2" /> Map Topology
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Wi-Fi Password Dumped: "HomeNet_5G" : "SuperSecret123"', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Key className="w-4 h-4 mr-2 text-yellow-500" /> Dump WiFi Keys
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('ARP Spoofing attack started on gateway.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Route className="w-4 h-4 mr-2" /> ARP Poisoning
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('DNS Cache Flushed and Poisoned.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Globe className="w-4 h-4 mr-2" /> DNS Poisoning
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Disconnecting target from WiFi...', 'error')} className="focus:bg-primary/20 cursor-pointer">
              <Wifi className="w-4 h-4 mr-2 text-red-500" /> Jam WiFi Signal
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Bluetooth devices scanned: 3 found.', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Bluetooth className="w-4 h-4 mr-2" /> Scan Bluetooth
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

        {/* DATA EXFILTRATION */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Database className="w-4 h-4 mr-2 text-purple-400" /> Data Exfiltration
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-64 bg-black/95 border border-primary/30 text-primary">
            <ContextMenuLabel className="text-xs text-primary/50">BROWSERS</ContextMenuLabel>
            <ContextMenuItem onClick={() => logAction('Stealing Chrome Cookies...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Cookie className="w-4 h-4 mr-2 text-orange-400" /> Chrome Cookies
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Stealing Firefox Cookies...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Cookie className="w-4 h-4 mr-2 text-orange-600" /> Firefox Cookies
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Stealing Edge Cookies...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Cookie className="w-4 h-4 mr-2 text-blue-500" /> Edge Cookies
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Dumped 42 Saved Passwords.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Key className="w-4 h-4 mr-2 text-yellow-400" /> Saved Passwords
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Credit Cards Found: 2 (VISA, MC)', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <CreditCard className="w-4 h-4 mr-2 text-red-400" /> Credit Cards
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Auto-fill Data Dumped.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <FileJson className="w-4 h-4 mr-2" /> Auto-fill Data
            </ContextMenuItem>
            
            <ContextMenuSeparator className="bg-primary/20" />
            <ContextMenuLabel className="text-xs text-primary/50">APPS</ContextMenuLabel>
            
            <ContextMenuItem onClick={() => logAction('Discord Token: mfa.Hz... (Valid)', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <MessageSquare className="w-4 h-4 mr-2 text-indigo-400" /> Discord Tokens
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Telegram Session Uploaded.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <MessageSquare className="w-4 h-4 mr-2 text-sky-400" /> Telegram Session
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Steam SSFN File Grabbed.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <GameIcon className="w-4 h-4 mr-2" /> Steam Session
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Outlook/Thunderbird Emails Dumped.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Mail className="w-4 h-4 mr-2" /> Email Clients
            </ContextMenuItem>
            
             <ContextMenuSeparator className="bg-primary/20" />
             <ContextMenuLabel className="text-xs text-primary/50">CRYPTO</ContextMenuLabel>
             
            <ContextMenuItem onClick={() => logAction('Metamask Vault Exfiltrated.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Wallet className="w-4 h-4 mr-2 text-orange-500" /> Metamask Vault
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Exodus Wallet Files.zip Uploaded.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Bitcoin className="w-4 h-4 mr-2 text-green-500" /> Exodus Wallet
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Binance Session Cookies Stolen.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <DollarSign className="w-4 h-4 mr-2 text-yellow-300" /> Binance Session
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Searching for wallet.dat files...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Search className="w-4 h-4 mr-2" /> Deep Wallet Search
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

        {/* CLIPPER / HIJACK */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Scissors className="w-4 h-4 mr-2 text-red-500" /> Clipper / Hijack
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-64 bg-black/95 border border-primary/30 text-primary">
            <ContextMenuItem onClick={() => logAction('Clipper Service: ENABLED (Monitoring Clipboard)', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Clipboard className="w-4 h-4 mr-2" /> Activate Clipper
            </ContextMenuItem>
            <ContextMenuSeparator className="bg-primary/20" />
            <ContextMenuItem onClick={() => logAction('Crypto Address Swap: BTC set to [bc1q...]', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Bitcoin className="w-4 h-4 mr-2" /> Auto-Swap BTC
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Crypto Address Swap: ETH set to [0x4a...]', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Hash className="w-4 h-4 mr-2" /> Auto-Swap ETH
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Crypto Address Swap: USDT set to [TEx9...]', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <DollarSign className="w-4 h-4 mr-2" /> Auto-Swap USDT
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Crypto Address Swap: XMR set to [44G...]', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Activity className="w-4 h-4 mr-2" /> Auto-Swap XMR
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Monitoring for Steam Trade Links...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <GameIcon className="w-4 h-4 mr-2" /> Steam Trade Links
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

        {/* SURVEILLANCE */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Eye className="w-4 h-4 mr-2 text-blue-400" /> Surveillance
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-56 bg-black/95 border border-primary/30 text-primary">
            <ContextMenuItem onClick={() => logAction('Webcam stream started [CAM_01]', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Video className="w-4 h-4 mr-2" /> Live Webcam
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Webcam Snapshot captured: snap_001.jpg', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Camera className="w-4 h-4 mr-2" /> Take Snapshot
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Microphone stream started.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Mic className="w-4 h-4 mr-2" /> Listen Microphone
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Screen Recording started (60fps).', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Disc className="w-4 h-4 mr-2" /> Record Screen
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Desktop Stream (RDP/VNC) started.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <MonitorOff className="w-4 h-4 mr-2" /> View Desktop
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Keylogger: STARTED logging to keys.log', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Keyboard className="w-4 h-4 mr-2" /> Start Keylogger
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Keylogger: Dumped 4059 keystrokes.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <FileText className="w-4 h-4 mr-2" /> Dump Keystrokes
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Location Tracking: [34.0522° N, 118.2437° W]', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Route className="w-4 h-4 mr-2" /> Geolocate Target
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

        {/* FILE SYSTEM */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <HardDrive className="w-4 h-4 mr-2" /> File System
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-56 bg-black/95 border border-primary/30 text-primary">
            <ContextMenuItem onClick={() => logAction('Browsing Root Directory C:/', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <FolderOpen className="w-4 h-4 mr-2" /> Browse Files
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('File Uploaded: payload.exe', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Upload className="w-4 h-4 mr-2" /> Upload File
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Downloading selected files...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Download className="w-4 h-4 mr-2" /> Download File
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Executed: silent_miner.exe', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Play className="w-4 h-4 mr-2" /> Execute
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Searching for *.pdf, *.docx, *.xlsx...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Search className="w-4 h-4 mr-2" /> Smart Search
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Ransomware: Encrypting User Documents...', 'error')} className="focus:bg-primary/20 cursor-pointer">
              <Lock className="w-4 h-4 mr-2 text-red-500" /> Encrypt Files
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Decryption Key Generated.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Key className="w-4 h-4 mr-2 text-green-500" /> Decrypt Files
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Secure Delete (7 passes) complete.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Trash2 className="w-4 h-4 mr-2" /> Secure Delete
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

        {/* SYSTEM CONTROL */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Cpu className="w-4 h-4 mr-2" /> System Control
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-56 bg-black/95 border border-primary/30 text-primary">
             <ContextMenuItem onClick={() => logAction('Listing Running Processes...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <List className="w-4 h-4 mr-2" /> Process List
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Registry Editor opened.', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <FileCode className="w-4 h-4 mr-2" /> Registry Editor
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('UAC Bypass (Fodhelper) initiated...', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <ShieldAlert className="w-4 h-4 mr-2" /> UAC Bypass
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Persistence added to HKCU/Run.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Save className="w-4 h-4 mr-2" /> Add Persistence
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Windows Defender Disabled.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <ShieldOff className="w-4 h-4 mr-2 text-red-500" /> Disable Defender
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Firewall Rules flushed.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <ShieldOff className="w-4 h-4 mr-2" /> Disable Firewall
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Task Manager Disabled.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Activity className="w-4 h-4 mr-2" /> Disable TaskMgr
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('CMD/Powershell Disabled.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <TerminalSquare className="w-4 h-4 mr-2" /> Disable CMD
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

         {/* HARDWARE FUN */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Settings className="w-4 h-4 mr-2 text-yellow-500" /> Hardware Pranks
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-56 bg-black/95 border border-primary/30 text-primary">
             <ContextMenuItem onClick={() => logAction('CD Tray Opened.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Disc className="w-4 h-4 mr-2" /> Eject CD Tray
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Monitor turned OFF.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <MonitorOff className="w-4 h-4 mr-2" /> Turn Off Monitor
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Printer Spam job sent.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Printer className="w-4 h-4 mr-2" /> Spam Printer
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('System Beep Loop started.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Speaker className="w-4 h-4 mr-2" /> Beep Loop
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>


        {/* FUN & TROLLING */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <Ghost className="w-4 h-4 mr-2 text-pink-500" /> Fun & Troll
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-56 bg-black/95 border border-primary/30 text-primary">
            <ContextMenuItem onClick={() => logAction('Message Box Displayed: "You have been hacked!"', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <MessageSquare className="w-4 h-4 mr-2" /> Show Message Box
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Browser opened to: www.youtube.com/watch?v=...', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Globe className="w-4 h-4 mr-2" /> Open URL
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Mouse and Keyboard Input BLOCKED.', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <MousePointer2 className="w-4 h-4 mr-2" /> Block Input
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Audio Played: scary_sound.mp3', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Speaker className="w-4 h-4 mr-2" /> Play Audio
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Wallpaper changed to hacked.jpg', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <Image className="w-4 h-4 mr-2" /> Change Wallpaper
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('BSOD Triggered!', 'error')} className="focus:bg-primary/20 cursor-pointer">
              <Skull className="w-4 h-4 mr-2 text-red-600" /> Trigger BSOD
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Fake Windows Update screen started.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <RefreshCcw className="w-4 h-4 mr-2" /> Fake Update
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Taskbar hidden.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <LayoutTemplate className="w-4 h-4 mr-2" /> Hide Taskbar
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>

        {/* ADVANCED */}
        <ContextMenuSub>
          <ContextMenuSubTrigger className="focus:bg-primary/20 cursor-pointer">
            <TerminalSquare className="w-4 h-4 mr-2" /> Advanced Ops
          </ContextMenuSubTrigger>
          <ContextMenuSubContent className="w-56 bg-black/95 border border-primary/30 text-primary">
             <ContextMenuItem onClick={() => logAction('Rootkit installation started...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Cpu className="w-4 h-4 mr-2" /> Install Rootkit
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('SMB EternalBlue Exploit attempt...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Network className="w-4 h-4 mr-2" /> SMB Exploit
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Hidden VNC Server installed.', 'success')} className="focus:bg-primary/20 cursor-pointer">
              <MonitorOff className="w-4 h-4 mr-2" /> Hidden VNC
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Credential Hunter script running...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <UserCheck className="w-4 h-4 mr-2" /> Credential Hunter
            </ContextMenuItem>
            <ContextMenuItem onClick={() => logAction('Lateral Movement: Scanning for neighbors...', 'info')} className="focus:bg-primary/20 cursor-pointer">
              <Share2 className="w-4 h-4 mr-2" /> Lateral Movement
            </ContextMenuItem>
             <ContextMenuItem onClick={() => logAction('Mimikatz: Dumping SAM/LSA...', 'warning')} className="focus:bg-primary/20 cursor-pointer">
              <Cat className="w-4 h-4 mr-2" /> Run Mimikatz
            </ContextMenuItem>
          </ContextMenuSubContent>
        </ContextMenuSub>
        
        <ContextMenuSeparator className="bg-primary/20" />
        
        <ContextMenuItem onClick={() => logAction('Target REBOOT initiated.', 'warning')} className="focus:bg-primary/20 cursor-pointer text-orange-500 focus:text-orange-500">
          <RefreshCcw className="w-4 h-4 mr-2" /> Reboot System
        </ContextMenuItem>
         <ContextMenuItem onClick={() => logAction('Target SHUTDOWN initiated.', 'error')} className="focus:bg-primary/20 cursor-pointer text-red-500 focus:text-red-500">
          <PowerOff className="w-4 h-4 mr-2" /> Shutdown
        </ContextMenuItem>
        <ContextMenuItem onClick={() => logAction('Connection TERMINATED. Client removed.', 'error')} className="focus:bg-primary/20 cursor-pointer text-red-500 focus:text-red-500">
          <Trash2 className="w-4 h-4 mr-2" /> Uninstall & Disconnect
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}

// Helper component for icon
function GameIcon({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <line x1="6" x2="10" y1="12" y2="12" />
      <line x1="8" x2="8" y1="10" y2="14" />
      <line x1="15" x2="15.01" y1="13" y2="13" />
      <line x1="18" x2="18.01" y1="11" y2="11" />
      <rect width="20" height="12" x="2" y="6" rx="2" />
    </svg>
  )
}

function LayoutTemplate({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="9" x2="9" y1="21" y2="9" />
    </svg>
  )
}

function Cat({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 5c.67 0 1.35.09 2 .26 1.78-2 5.03-2.84 6.42-2.26 1.4.58-.42 7-.42 7 .57 1.07 1 2.24 1 3.44C21 17.9 16.97 21 12 21s-9-3.1-9-7.56c0-1.25.5-2.4 1-3.44 0 0-1.89-6.42-.5-7 1.39-.58 4.67.26 6.5 2.26.61-.17 1.29-.26 2-.26Z" />
    </svg>
  )
}
