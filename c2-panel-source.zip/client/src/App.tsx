import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Dashboard from "@/pages/dashboard";
import Builder from "@/pages/builder";
import Auth from "@/pages/auth";
import Setup from "@/pages/setup";
import FileManager from "@/pages/files";
import ScreenMonitor from "@/pages/screen";
import Targets from "@/pages/targets";
import Vault from "@/pages/vault";
import Mining from "@/pages/mining";
import ConsolePage from "@/pages/console";
import NetworkPage from "@/pages/network";
import ProcessManager from "@/pages/processes";
import KeyloggerPage from "@/pages/keylogger";
import WebcamPage from "@/pages/webcam";
import NotFound from "@/pages/not-found";
import { useEffect, useState } from "react";

function ProtectedRoute({ component: Component, ...rest }: any) {
  const [location, setLocation] = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  const { data: config, isLoading } = useQuery({
    queryKey: ["/api/config"],
    queryFn: async () => {
      const res = await fetch("/api/config");
      if (!res.ok) return null;
      return res.json();
    },
  });

  useEffect(() => {
    const auth = localStorage.getItem("isAuthenticated");
    if (auth === "true") {
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
      setLocation("/auth");
    }
  }, [setLocation]);

  useEffect(() => {
    if (!isLoading && isAuthenticated && !config) {
      setLocation("/setup");
    }
  }, [config, isLoading, isAuthenticated, setLocation]);

  if (isAuthenticated === null || isLoading) {
    return null;
  }

  if (!isAuthenticated) {
    return null;
  }

  return <Component {...rest} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={Auth} />
      <Route path="/setup" component={Setup} />
      <Route path="/">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/builder">
        <ProtectedRoute component={Builder} />
      </Route>
      <Route path="/files">
        <ProtectedRoute component={FileManager} />
      </Route>
      <Route path="/screen">
        <ProtectedRoute component={ScreenMonitor} />
      </Route>
      <Route path="/targets">
        <ProtectedRoute component={Targets} />
      </Route>
      <Route path="/vault">
        <ProtectedRoute component={Vault} />
      </Route>
      <Route path="/mining">
        <ProtectedRoute component={Mining} />
      </Route>
      <Route path="/console">
        <ProtectedRoute component={ConsolePage} />
      </Route>
      <Route path="/network">
        <ProtectedRoute component={NetworkPage} />
      </Route>
      <Route path="/processes">
        <ProtectedRoute component={ProcessManager} />
      </Route>
      <Route path="/keylogger">
        <ProtectedRoute component={KeyloggerPage} />
      </Route>
      <Route path="/webcam">
        <ProtectedRoute component={WebcamPage} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="animate-scanline" />
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
