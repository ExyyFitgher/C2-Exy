import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GlitchText } from "@/components/ui/glitch-text";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { Server, Key, Globe, Loader2 } from "lucide-react";

export default function Setup() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [port, setPort] = useState("8080");
  const [secretKey, setSecretKey] = useState("");
  const [domain, setDomain] = useState("");

  const setupMutation = useMutation({
    mutationFn: async (data: { port: number; secretKey: string; domain: string }) => {
      const res = await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create config");
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "SERVER INITIALIZED",
        description: "Configuration saved. Redirecting to command center...",
      });
      localStorage.setItem("isConfigured", "true");
      setTimeout(() => setLocation("/"), 1500);
    },
    onError: () => {
      toast({
        title: "INITIALIZATION FAILED",
        description: "Could not save configuration. Try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!port || !secretKey || !domain) {
      toast({
        title: "MISSING FIELDS",
        description: "All fields are required.",
        variant: "destructive",
      });
      return;
    }
    setupMutation.mutate({
      port: parseInt(port),
      secretKey,
      domain,
    });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 font-mono">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
      
      <Card className="w-full max-w-md bg-black/80 border-primary/30 backdrop-blur-md relative z-10">
        <CardHeader className="text-center border-b border-primary/20 pb-6">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 border border-primary/30">
            <Server className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">
            <GlitchText text="EXY ATTACK" />
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-2">
            CONFIGURE YOUR C2 SERVER
          </p>
        </CardHeader>
        
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="port" className="text-xs uppercase text-primary/80 flex items-center gap-2">
                <Server className="w-3 h-3" /> Listening Port
              </Label>
              <Input
                id="port"
                type="number"
                value={port}
                onChange={(e) => setPort(e.target.value)}
                placeholder="8080"
                className="bg-black/50 border-primary/30 text-primary font-mono"
                data-testid="input-port"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="secretKey" className="text-xs uppercase text-primary/80 flex items-center gap-2">
                <Key className="w-3 h-3" /> Secret Key
              </Label>
              <Input
                id="secretKey"
                type="password"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                placeholder="Enter your secret key"
                className="bg-black/50 border-primary/30 text-primary font-mono"
                data-testid="input-secret-key"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="domain" className="text-xs uppercase text-primary/80 flex items-center gap-2">
                <Globe className="w-3 h-3" /> Domain / IP Address
              </Label>
              <Input
                id="domain"
                type="text"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                placeholder="your-domain.com or IP address"
                className="bg-black/50 border-primary/30 text-primary font-mono"
                data-testid="input-domain"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-primary/20 hover:bg-primary/30 border border-primary/50 text-primary font-bold"
              disabled={setupMutation.isPending}
              data-testid="button-initialize"
            >
              {setupMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  INITIALIZING...
                </>
              ) : (
                "INITIALIZE SERVER"
              )}
            </Button>
          </form>

          <div className="mt-6 p-3 bg-primary/5 rounded border border-primary/20">
            <p className="text-[10px] text-primary/60 text-center">
              Encrypted connection will be established using AES-256
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
