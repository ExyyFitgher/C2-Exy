import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Terminal } from "@/components/ui/terminal";
import { GlitchText } from "@/components/ui/glitch-text";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";

export default function ConsolePage() {
  const [logs, setLogs] = useState<string[]>([
    "Console initialized...",
    "System ready.",
    "Type 'help' for available commands."
  ]);
  const [command, setCommand] = useState("");

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;

    const newLogs = [...logs, `> ${command}`];
    
    // Simple mock command handling
    if (command.toLowerCase() === "help") {
      newLogs.push("Available commands: help, clear, status, scan, connect");
    } else if (command.toLowerCase() === "clear") {
      setLogs([]);
      setCommand("");
      return;
    } else if (command.toLowerCase() === "status") {
      newLogs.push("System Status: ONLINE");
      newLogs.push("Encryption: ACTIVE");
      newLogs.push("Network: CONNECTED");
    } else {
      newLogs.push(`Command not found: ${command}`);
    }

    setLogs(newLogs);
    setCommand("");
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="SYSTEM // CONSOLE" />
            </h1>
          </div>
        </header>

        <div className="flex-1 p-6 flex flex-col gap-4 overflow-hidden">
          <Terminal logs={logs} className="flex-1 bg-black/60 shadow-[0_0_20px_rgba(0,255,65,0.05)]" />
          
          <form onSubmit={handleCommand} className="flex gap-2">
            <div className="relative flex-1">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-primary animate-pulse">{">"}</div>
              <Input 
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                className="pl-8 bg-black/40 border-primary/30 text-primary font-mono focus-visible:ring-primary/50"
                placeholder="Enter command..."
                autoFocus
              />
            </div>
            <Button type="submit" variant="outline" className="border-primary/30 text-primary hover:bg-primary/10">
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </main>
    </div>
  );
}
