import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Pickaxe, 
  Coins, 
  Zap, 
  Cpu, 
  Activity, 
  PlayCircle, 
  StopCircle,
  Wallet
} from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export default function Mining() {
  const [isMining, setIsMining] = useState(false);
  const [hashrate, setHashrate] = useState(0);

  useEffect(() => {
    if (isMining) {
      const interval = setInterval(() => {
        setHashrate(prev => Math.min(prev + Math.random() * 50, 4500));
      }, 500);
      return () => clearInterval(interval);
    } else {
      setHashrate(0);
    }
  }, [isMining]);

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="SILENT_MINER // CRYPTO_OPS" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-yellow-500">
             <Pickaxe className="w-4 h-4 animate-bounce" />
             <span>POOL STATUS: ONLINE</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 pb-20">
          <div className="max-w-5xl mx-auto space-y-6">
            
            {/* Wallet Config */}
            <Card className="bg-black/40 border-primary/20 backdrop-blur-md">
               <CardHeader className="border-b border-primary/10 pb-4">
                 <CardTitle className="text-sm font-mono uppercase text-primary flex items-center gap-2">
                   <Wallet className="w-4 h-4" /> Wallet Configuration
                 </CardTitle>
               </CardHeader>
               <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="space-y-2">
                   <Label className="text-xs uppercase text-primary/70">Cryptocurrency</Label>
                   <Select defaultValue="xmr">
                     <SelectTrigger className="bg-black/50 border-primary/20 text-primary">
                       <SelectValue placeholder="Select Coin" />
                     </SelectTrigger>
                     <SelectContent className="bg-black border-primary/20 text-primary">
                       <SelectItem value="xmr">Monero (XMR) - CPU Optimized</SelectItem>
                       <SelectItem value="eth">Ethereum (ETH) - GPU Only</SelectItem>
                       <SelectItem value="etc">Ethereum Classic (ETC)</SelectItem>
                       <SelectItem value="rvn">Ravencoin (RVN)</SelectItem>
                       <SelectItem value="btc">Bitcoin (BTC) - Slow</SelectItem>
                     </SelectContent>
                   </Select>
                 </div>
                 <div className="space-y-2">
                   <Label className="text-xs uppercase text-primary/70">Wallet Address</Label>
                   <Input 
                     className="bg-black/50 border-primary/20 text-primary focus:border-primary/60 font-mono text-xs"
                     placeholder="44AFFq5kSiGBoZ4NMDwYtN18..."
                   />
                 </div>
               </CardContent>
            </Card>

            {/* Mining Control */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <Card className="md:col-span-2 bg-black/40 border-primary/20 backdrop-blur-md flex flex-col">
                  <CardHeader className="border-b border-primary/10 pb-4">
                    <CardTitle className="text-sm font-mono uppercase text-primary flex items-center justify-between">
                      <div className="flex items-center gap-2"><Activity className="w-4 h-4" /> Mining Performance</div>
                      <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5">
                        {isMining ? "MINING ACTIVE" : "IDLE"}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 flex-1 flex flex-col justify-end space-y-4">
                     <div className="h-40 flex items-end gap-1 pb-4 border-b border-primary/10">
                        {[...Array(30)].map((_, i) => (
                           <motion.div 
                             key={i}
                             className="flex-1 bg-primary/20"
                             animate={{ 
                               height: isMining ? `${Math.random() * 80 + 20}%` : "5%"
                             }}
                             transition={{
                               duration: 0.5,
                               repeat: Infinity,
                               repeatType: "reverse",
                               delay: i * 0.02
                             }}
                           />
                        ))}
                     </div>
                     <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-white">{Math.floor(hashrate)} H/s</div>
                          <div className="text-[10px] text-muted-foreground uppercase">Total Hashrate</div>
                        </div>
                         <div>
                          <div className="text-2xl font-bold text-white">{isMining ? "42" : "0"}</div>
                          <div className="text-[10px] text-muted-foreground uppercase">Active Workers</div>
                        </div>
                         <div>
                          <div className="text-2xl font-bold text-white">{isMining ? "0.0042" : "0.0000"}</div>
                          <div className="text-[10px] text-muted-foreground uppercase">Est. Revenue (XMR)</div>
                        </div>
                     </div>
                  </CardContent>
               </Card>

               <div className="space-y-6">
                 <Card className="bg-black/40 border-primary/20 backdrop-blur-md">
                   <CardContent className="p-6 space-y-4">
                      <div className="space-y-2">
                        <Label className="text-xs uppercase text-primary/70">CPU Usage Limit</Label>
                        <div className="flex items-center gap-2">
                           <Progress value={75} className="h-2 bg-primary/20" />
                           <span className="text-xs text-primary font-bold">75%</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs uppercase text-primary/70">Thread Count</Label>
                         <Select defaultValue="auto">
                           <SelectTrigger className="h-8 bg-black/50 border-primary/20 text-primary text-xs">
                             <SelectValue placeholder="Threads" />
                           </SelectTrigger>
                           <SelectContent className="bg-black border-primary/20 text-primary">
                             <SelectItem value="auto">Auto (Recommended)</SelectItem>
                             <SelectItem value="2">2 Threads</SelectItem>
                             <SelectItem value="4">4 Threads</SelectItem>
                             <SelectItem value="max">Max Performance</SelectItem>
                           </SelectContent>
                         </Select>
                      </div>
                      <Button 
                         className={cn(
                           "w-full h-12 font-bold tracking-widest mt-2",
                           isMining 
                             ? "bg-red-500 hover:bg-red-600 text-white" 
                             : "bg-primary hover:bg-primary/90 text-black"
                         )}
                         onClick={() => setIsMining(!isMining)}
                      >
                         {isMining ? <><StopCircle className="w-4 h-4 mr-2" /> STOP ALL MINERS</> : <><PlayCircle className="w-4 h-4 mr-2" /> START MINING</>}
                      </Button>
                   </CardContent>
                 </Card>
                 
                 <Card className="bg-yellow-500/10 border-yellow-500/20 backdrop-blur-md">
                    <CardContent className="p-4 flex items-center gap-3">
                       <Coins className="w-8 h-8 text-yellow-500" />
                       <div>
                         <div className="text-lg font-bold text-white">0.000000</div>
                         <div className="text-[10px] text-yellow-500/70 uppercase">Total Balance (Pending)</div>
                       </div>
                    </CardContent>
                 </Card>
               </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
