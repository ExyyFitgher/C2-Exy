import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Folder, 
  FileText, 
  Image as ImageIcon, 
  Music, 
  Video, 
  Download, 
  Trash2, 
  HardDrive,
  ChevronRight,
  Home,
  ArrowUp
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

// Mock File System
const MOCK_FILES = [
  { id: 1, name: "Documents", type: "folder", size: "--", date: "2024-03-10" },
  { id: 2, name: "Downloads", type: "folder", size: "--", date: "2024-03-12" },
  { id: 3, name: "DCIM", type: "folder", size: "--", date: "2024-02-28" },
  { id: 4, name: "passwords.txt", type: "file", size: "2.4 KB", date: "2024-03-14" },
  { id: 5, name: "config.json", type: "file", size: "14 KB", date: "2024-01-05" },
  { id: 6, name: "screenshot_001.png", type: "image", size: "2.1 MB", date: "2024-03-14" },
  { id: 7, name: "backup_wallet.dat", type: "file", size: "450 KB", date: "2023-12-20" },
];

export default function FileManager() {
  const [currentPath, setCurrentPath] = useState(["root", "sdcard"]);
  const [selectedFile, setSelectedFile] = useState<number | null>(null);

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="REMOTE_FILE_EXPLORER" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-primary/60">
             <HardDrive className="w-4 h-4 animate-pulse" />
             <span>TARGET: ADMIN-PC</span>
          </div>
        </header>

        <div className="flex-1 overflow-hidden flex flex-col p-6 pb-20">
          <Card className="flex-1 bg-black/40 border-primary/20 backdrop-blur-md flex flex-col overflow-hidden">
            {/* Toolbar */}
            <div className="p-4 border-b border-primary/10 flex items-center gap-4 bg-primary/5">
              <Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:bg-primary/20">
                <ArrowUp className="w-4 h-4" />
              </Button>
              
              <div className="flex-1 flex items-center gap-2 px-3 py-1.5 bg-black/50 border border-primary/20 rounded text-sm font-mono text-primary/80">
                <Home className="w-3 h-3" />
                {currentPath.map((folder, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <ChevronRight className="w-3 h-3 opacity-50" />
                    <span>{folder}</span>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  disabled={!selectedFile}
                  className="bg-primary/10 text-primary hover:bg-primary hover:text-black border border-primary/30"
                >
                  <Download className="w-4 h-4 mr-2" />
                  DOWNLOAD
                </Button>
                <Button 
                  size="sm" 
                  disabled={!selectedFile}
                  className="bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white border border-red-500/30"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  DELETE
                </Button>
              </div>
            </div>

            {/* File Grid */}
            <div className="flex-1 overflow-y-auto p-4">
              <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {MOCK_FILES.map((file) => (
                  <div
                    key={file.id}
                    onClick={() => setSelectedFile(file.id)}
                    className={cn(
                      "p-4 rounded border flex flex-col items-center gap-3 cursor-pointer transition-all duration-200 group hover:bg-primary/5",
                      selectedFile === file.id 
                        ? "border-primary bg-primary/10 shadow-[0_0_15px_rgba(0,255,65,0.1)]" 
                        : "border-transparent hover:border-primary/30"
                    )}
                  >
                    <div className="w-12 h-12 flex items-center justify-center text-primary/80 group-hover:text-primary group-hover:scale-110 transition-transform">
                      {file.type === 'folder' && <Folder className="w-full h-full fill-primary/20" />}
                      {file.type === 'file' && <FileText className="w-full h-full" />}
                      {file.type === 'image' && <ImageIcon className="w-full h-full" />}
                    </div>
                    <div className="text-center w-full">
                      <div className="text-xs font-bold truncate w-full text-primary/90">{file.name}</div>
                      <div className="text-[10px] text-muted-foreground mt-1 flex justify-between w-full px-2">
                        <span>{file.size}</span>
                        <span>{file.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="p-2 border-t border-primary/10 bg-black/50 text-[10px] text-primary/40 text-right px-4">
              7 items | 2.56 MB used
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
