import { useState, useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Cpu, Activity, ShieldAlert, Power, RefreshCw, Filter, Shield } from "lucide-react";

interface Process {
  id: number;
  name: string;
  pid: number;
  user: string;
  cpu: number;
  memory: string;
  status: "running" | "suspended" | "not responding";
  isSystem: boolean;
  isInfected?: boolean;
}

export default function ProcessManager() {
  const [processes, setProcesses] = useState<Process[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPid, setSelectedPid] = useState<number | null>(null);

  useEffect(() => {
    // Generate mock processes
    const mockProcesses: Process[] = [
      { id: 1, name: "System Idle Process", pid: 0, user: "SYSTEM", cpu: 85.2, memory: "8 K", status: "running", isSystem: true },
      { id: 2, name: "System", pid: 4, user: "SYSTEM", cpu: 0.1, memory: "1.2 MB", status: "running", isSystem: true },
      { id: 3, name: "smss.exe", pid: 348, user: "SYSTEM", cpu: 0.0, memory: "540 K", status: "running", isSystem: true },
      { id: 4, name: "csrss.exe", pid: 520, user: "SYSTEM", cpu: 0.0, memory: "4.5 MB", status: "running", isSystem: true },
      { id: 5, name: "wininit.exe", pid: 612, user: "SYSTEM", cpu: 0.0, memory: "1.8 MB", status: "running", isSystem: true },
      { id: 6, name: "services.exe", pid: 704, user: "SYSTEM", cpu: 0.1, memory: "6.2 MB", status: "running", isSystem: true },
      { id: 7, name: "lsass.exe", pid: 720, user: "SYSTEM", cpu: 0.2, memory: "12.5 MB", status: "running", isSystem: true },
      { id: 8, name: "svchost.exe", pid: 890, user: "NETWORK SERVICE", cpu: 0.0, memory: "8.4 MB", status: "running", isSystem: true },
      { id: 9, name: "svchost.exe", pid: 944, user: "LOCAL SERVICE", cpu: 0.0, memory: "5.1 MB", status: "running", isSystem: true },
      // The "Infected" Process disguised as System
      { id: 10, name: "winlogon.exe", pid: 1024, user: "SYSTEM", cpu: 1.2, memory: "14.2 MB", status: "running", isSystem: true, isInfected: true },
      { id: 11, name: "explorer.exe", pid: 4520, user: "Admin", cpu: 2.5, memory: "145.8 MB", status: "running", isSystem: false },
      { id: 12, name: "chrome.exe", pid: 5600, user: "Admin", cpu: 4.8, memory: "450.2 MB", status: "running", isSystem: false },
      { id: 13, name: "chrome.exe", pid: 5644, user: "Admin", cpu: 0.5, memory: "120.5 MB", status: "running", isSystem: false },
      { id: 14, name: "discord.exe", pid: 7820, user: "Admin", cpu: 0.2, memory: "250.4 MB", status: "running", isSystem: false },
    ];
    setProcesses(mockProcesses);
  }, []);

  const filteredProcesses = processes.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.pid.toString().includes(searchQuery)
  );

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="SYSTEM // PROCESS_MANAGER" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-primary/60">
            <Activity className="w-4 h-4 animate-pulse" />
            <span>LIVE MONITORING</span>
          </div>
        </header>

        <div className="flex-1 overflow-hidden p-6 flex flex-col gap-4">
          
          {/* Controls */}
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary/50" />
              <Input 
                placeholder="Filter processes..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-black/40 border-primary/20 text-primary focus:border-primary/60 font-mono text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
               <Button variant="outline" size="sm" className="border-primary/30 text-primary hover:bg-primary/10 gap-2">
                 <RefreshCw className="w-4 h-4" /> Refresh
               </Button>
               <Button variant="outline" size="sm" className="border-primary/30 text-primary hover:bg-primary/10 gap-2">
                 <Filter className="w-4 h-4" /> System Only
               </Button>
            </div>
          </div>

          {/* Process Table */}
          <Card className="flex-1 bg-black/40 border-primary/30 overflow-hidden flex flex-col">
            <CardHeader className="border-b border-primary/10 py-3 px-4">
              <div className="grid grid-cols-12 text-xs font-bold text-primary/70 uppercase tracking-wider">
                <div className="col-span-4">Image Name</div>
                <div className="col-span-2">PID</div>
                <div className="col-span-2">User Name</div>
                <div className="col-span-1">CPU</div>
                <div className="col-span-1">Mem</div>
                <div className="col-span-2 text-right">Status</div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-y-auto">
              <div className="divide-y divide-primary/5">
                {filteredProcesses.map((process) => (
                  <div 
                    key={process.id}
                    onClick={() => setSelectedPid(process.pid)}
                    className={`grid grid-cols-12 px-4 py-2 text-xs font-mono cursor-pointer transition-colors ${
                      selectedPid === process.pid 
                        ? "bg-primary/20 text-white" 
                        : "hover:bg-primary/5 text-muted-foreground"
                    }`}
                  >
                    <div className="col-span-4 flex items-center gap-2">
                      {process.isInfected ? (
                        <ShieldAlert className="w-3 h-3 text-yellow-500 animate-pulse" />
                      ) : process.isSystem ? (
                         <Shield className="w-3 h-3 text-primary/40" />
                      ) : (
                         <Cpu className="w-3 h-3 text-muted-foreground/40" />
                      )}
                      <span className={process.isInfected ? "text-yellow-400 font-bold" : ""}>
                        {process.name}
                      </span>
                      {process.isInfected && (
                        <Badge variant="outline" className="h-4 text-[9px] px-1 border-yellow-500/50 text-yellow-400 bg-yellow-500/10">
                          ROOTKIT
                        </Badge>
                      )}
                    </div>
                    <div className="col-span-2">{process.pid}</div>
                    <div className="col-span-2">{process.user}</div>
                    <div className="col-span-1">{process.cpu}%</div>
                    <div className="col-span-1">{process.memory}</div>
                    <div className="col-span-2 text-right">
                       <span className={process.status === "running" ? "text-green-500" : "text-yellow-500"}>
                         {process.status.toUpperCase()}
                       </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Details Panel (Mock) */}
          {selectedPid && (
            <div className="h-32 bg-black/60 border border-primary/20 rounded-md p-4 flex gap-6 animate-in slide-in-from-bottom-4">
               <div className="space-y-2">
                 <h3 className="text-sm font-bold text-primary">Process Information</h3>
                 <div className="text-xs text-muted-foreground space-y-1">
                   <div>Path: C:\Windows\System32\{processes.find(p => p.pid === selectedPid)?.name}</div>
                   <div>Command Line: --no-sandbox --system-level</div>
                   <div>Started: 14/12/2025 08:30:22</div>
                 </div>
               </div>
               <div className="flex-1 flex justify-end items-start gap-2">
                 <Button variant="destructive" size="sm" className="h-8 text-xs gap-2">
                   <Power className="w-3 h-3" /> Terminate
                 </Button>
                 <Button variant="outline" size="sm" className="h-8 text-xs border-primary/30 text-primary gap-2">
                   <Activity className="w-3 h-3" /> Dump Memory
                 </Button>
               </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
