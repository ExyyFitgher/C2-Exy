import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Terminal } from "@/components/ui/terminal";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { 
  Wifi, 
  Cpu, 
  Cookie, 
  Key, 
  Monitor, 
  Laptop,
  Users,
  Activity,
  Play,
  ShieldAlert,
  Loader2
} from "lucide-react";

import { TargetContextMenu } from "@/components/ui/target-context-menu";

interface Target {
  id: string;
  targetId: string;
  name: string;
  ip: string;
  os: string;
  status: string;
  country: string;
}

interface Log {
  id: string;
  message: string;
  type: string;
  createdAt: string;
}

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [localLogs, setLocalLogs] = useState<string[]>([]);

  const { data: targets = [], isLoading: targetsLoading } = useQuery<Target[]>({
    queryKey: ["/api/targets"],
    queryFn: async () => {
      const res = await fetch("/api/targets");
      if (!res.ok) throw new Error("Failed to fetch targets");
      return res.json();
    },
    refetchInterval: 5000,
  });

  const { data: logsData = [] } = useQuery<Log[]>({
    queryKey: ["/api/logs"],
    queryFn: async () => {
      const res = await fetch("/api/logs");
      if (!res.ok) throw new Error("Failed to fetch logs");
      return res.json();
    },
    refetchInterval: 3000,
  });

  const logs = logsData.map(log => log.message).reverse().concat(localLogs);

  const simulateMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/simulate-connection", { method: "POST" });
      if (!res.ok) throw new Error("Failed to simulate connection");
      return res.json();
    },
    onSuccess: (target: Target) => {
      queryClient.invalidateQueries({ queryKey: ["/api/targets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      toast({
        title: "NEW SESSION ESTABLISHED",
        description: `Connection received from ${target.ip}`,
        variant: "destructive",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "CONNECTION FAILED",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const simulatePersistence = () => {
    if (targets.length === 0) return;

    const processNames = [
      "svchost.exe", "taskhostw.exe", "runtimebroker.exe", "wininit.exe",
      "services.exe", "lsass.exe", "csrss.exe", "spoolsv.exe"
    ];
    const randomProcess = processNames[Math.floor(Math.random() * processNames.length)];
    const randomPid = Math.floor(Math.random() * 8000) + 1000;

    const steps = [
      { msg: "[*] LISTENING ON PORT 8080...", delay: 200 },
      { msg: "[>] INITIATING PERSISTENCE MODULE...", delay: 500 },
      { msg: "[>] DOWNLOADING PAYLOAD: stub.exe (2.4MB)", delay: 1000 },
      { msg: "[>] EXECUTING: %APPDATA%\\SystemConfig\\stub.exe", delay: 1500 },
      { msg: "[>] BINDING DEVICE TO VERSION: KERNEL_LEVEL_V2", delay: 1800 },
      { msg: "[>] SETTING ATTRIBUTES: +H +S +R (HIDDEN)", delay: 2200 },
      { msg: "[>] OPENING REGISTRY: Computer\\HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", delay: 2800 },
      { msg: "[+] WRITING KEY: 'WinSystemUpdater' -> %APPDATA%\\SystemConfig\\stub.exe", delay: 3400 },
      { msg: `[>] PROCESS INJECTED: ${randomProcess} (PID: ${randomPid})`, delay: 4000 },
      { msg: "[+] VERIFYING PERSISTENCE... OK", delay: 4500 },
      { msg: "[*] OPERATION COMPLETE: TARGET BOUND TO SERVER", delay: 5000 }
    ];

    steps.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setLocalLogs(prev => [...prev, msg]);
      }, delay);
    });
  };

  useEffect(() => {
    const handleHackLog = (e: CustomEvent<{ message: string; type: string }>) => {
      setLocalLogs(prev => [...prev, e.detail.message]);
    };
    window.addEventListener('hack-log', handleHackLog as EventListener);
    return () => window.removeEventListener('hack-log', handleHackLog as EventListener);
  }, []);

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="COMMAND_CENTER // DASHBOARD" />
            </h1>
          </div>
          <div className="flex items-center gap-4 text-xs text-primary/60">
            <Button 
              size="sm" 
              variant="outline" 
              className="h-7 text-xs border-primary/30 text-primary hover:bg-primary/10 gap-2"
              onClick={() => simulateMutation.mutate()}
              disabled={simulateMutation.isPending}
              data-testid="button-simulate-connection"
            >
              {simulateMutation.isPending ? (
                <Loader2 className="w-3 h-3 animate-spin" />
              ) : (
                <Play className="w-3 h-3" />
              )}
              SIMULATE CONNECTION
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              className="h-7 text-xs border-red-500/30 text-red-500 hover:bg-red-500/10 gap-2"
              onClick={simulatePersistence}
              data-testid="button-inject-persistence"
            >
              <ShieldAlert className="w-3 h-3" /> INJECT PERSISTENCE
            </Button>
            <span>UPTIME: 00:00:00</span>
            <span>|</span>
            <span>ENCRYPTION: AES-256</span>
            <span>|</span>
            <div className="flex items-center gap-2 text-primary/50">
              <div className={`w-2 h-2 rounded-full ${targets.length > 0 ? 'bg-green-500' : 'bg-yellow-500 animate-pulse'}`} />
              {targets.length > 0 ? `${targets.length} ONLINE` : 'WAITING FOR CLIENTS'}
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-12 gap-6 pb-20">
          <div className="col-span-12 grid grid-cols-1 md:grid-cols-4 gap-4">
            <StatCard icon={Users} label="Active Targets" value={targets.length.toString()} sub={targets.length > 0 ? "Connected" : "Waiting..."} />
            <StatCard icon={Cookie} label="Sessions Captured" value={(targets.length * 12).toString()} sub={targets.length > 0 ? "Harvesting..." : "No Data"} />
            <StatCard icon={Key} label="Creds Harvested" value={(targets.length * 5).toString()} sub={targets.length > 0 ? "Analyzing..." : "No Data"} />
            <StatCard icon={Wifi} label="Network Load" value={`${targets.length * 45} KB/s`} sub="Traffic Active" />
          </div>

          <div className="col-span-12 md:col-span-8 space-y-6">
            <Card className="bg-black/40 border-primary/30 backdrop-blur-md">
              <CardHeader className="border-b border-primary/10 pb-3">
                <CardTitle className="text-sm font-mono uppercase text-primary flex items-center gap-2">
                  <Monitor className="w-4 h-4" /> Live Targets
                  {targetsLoading && <Loader2 className="w-3 h-3 animate-spin" />}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="w-full text-left text-sm">
                  <div className="grid grid-cols-12 p-3 text-xs text-muted-foreground border-b border-primary/10 bg-primary/5">
                    <div className="col-span-3">ID / NAME</div>
                    <div className="col-span-3">IP ADDRESS</div>
                    <div className="col-span-3">OS</div>
                    <div className="col-span-3">STATUS</div>
                  </div>
                  
                  {targets.length === 0 ? (
                    <div className="p-8 text-center text-muted-foreground text-xs italic opacity-50 flex flex-col items-center gap-2">
                      <Wifi className="w-8 h-8 opacity-20" />
                      No active connections found.
                    </div>
                  ) : (
                    <div className="divide-y divide-primary/10">
                      {targets.map((target) => (
                        <TargetContextMenu key={target.id} targetName={target.targetId}>
                          <div 
                            className="grid grid-cols-12 p-3 text-xs hover:bg-primary/5 transition-colors cursor-pointer group"
                            data-testid={`target-row-${target.targetId}`}
                          >
                            <div className="col-span-3 font-bold text-primary flex items-center gap-2">
                              <Monitor className="w-3 h-3 text-primary/70" />
                              {target.targetId}
                            </div>
                            <div className="col-span-3 text-primary/80 font-mono">{target.ip}</div>
                            <div className="col-span-3 text-muted-foreground flex items-center gap-2">
                              <Laptop className="w-3 h-3" />
                              {target.os}
                            </div>
                            <div className="col-span-3 flex items-center gap-2">
                              <Badge 
                                variant="outline" 
                                className={cn(
                                  "h-5 text-[10px]",
                                  target.status === "online" 
                                    ? "border-green-500/50 text-green-400 bg-green-500/10"
                                    : "border-yellow-500/50 text-yellow-400 bg-yellow-500/10"
                                )}
                              >
                                {target.status.toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                        </TargetContextMenu>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-6">
              <Card className="bg-black/40 border-primary/30 h-64 flex flex-col">
                <CardHeader className="border-b border-primary/10 py-3">
                  <CardTitle className="text-sm font-mono uppercase text-primary flex items-center gap-2">
                    <Activity className="w-4 h-4" /> Network Traffic
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex items-center justify-center p-4">
                  <div className="text-xs text-muted-foreground opacity-50">
                    {targets.length > 0 ? (
                      <div className="w-full h-full flex flex-col items-center justify-center gap-2">
                        <Activity className="w-8 h-8 animate-pulse text-green-500" />
                        <span>ENCRYPTED STREAM ACTIVE</span>
                      </div>
                    ) : "NO TRAFFIC DETECTED"}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-primary/30 h-64 flex flex-col">
                <CardHeader className="border-b border-primary/10 py-3">
                  <CardTitle className="text-sm font-mono uppercase text-primary flex items-center gap-2">
                    <Cpu className="w-4 h-4" /> System Resources
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>CPU Load</span>
                      <span>{targets.length * 12}%</span>
                    </div>
                    <Progress value={targets.length * 12} className="h-2 bg-primary/20" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Memory</span>
                      <span>{(targets.length * 0.8).toFixed(1)} GB / 16 GB</span>
                    </div>
                    <Progress value={targets.length * 5} className="h-2 bg-primary/20" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Storage</span>
                      <span>{(targets.length * 0.2).toFixed(1)} GB Used</span>
                    </div>
                    <Progress value={targets.length * 2} className="h-2 bg-primary/20" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="col-span-12 md:col-span-4 h-full min-h-[500px]">
            <Terminal logs={logs} className="h-full border-primary/30 bg-black/60 shadow-[0_0_20px_rgba(0,255,65,0.1)]" />
          </div>
        </div>
      </main>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sub }: { icon: any; label: string; value: string; sub: string }) {
  return (
    <Card className="bg-primary/5 border-primary/20 backdrop-blur-sm">
      <CardContent className="p-4 flex items-center justify-between">
        <div>
          <div className="text-[10px] uppercase text-primary/60 font-bold mb-1">{label}</div>
          <div className="text-2xl font-display font-bold text-white tracking-wide">{value}</div>
          <div className="text-[10px] text-primary/40 mt-1">{sub}</div>
        </div>
        <div className="p-2 bg-primary/10 rounded border border-primary/20">
          <Icon className="w-5 h-5 text-primary" />
        </div>
      </CardContent>
    </Card>
  );
}
