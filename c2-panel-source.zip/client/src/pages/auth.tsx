import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { ShieldCheck, Lock, Terminal, Loader2, XCircle, Globe } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Auth() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("");
  const [port, setPort] = useState("");
  const [key, setKey] = useState("");
  const [domain, setDomain] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    localStorage.removeItem("isAuthenticated");
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setStatus("Initializing connection...");

    if (!port || parseInt(port) < 1 || parseInt(port) > 65535) {
      setLoading(false);
      setError("INVALID PORT RANGE (1-65535)");
      return;
    }

    if (key.length < 8) {
      setLoading(false);
      setError("INVALID KEY LENGTH (MIN 8 CHARS)");
      return;
    }

    if (!domain) {
      setLoading(false);
      setError("DOMAIN/IP REQUIRED");
      return;
    }

    try {
      setStatus(`Pinging port ${port}...`);
      await new Promise(r => setTimeout(r, 800));

      setStatus("Port detected. Verifying credentials...");
      await new Promise(r => setTimeout(r, 1000));

      const response = await fetch("/api/config/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          port: parseInt(port),
          secretKey: key,
          domain: domain
        })
      });

      if (!response.ok) {
        const data = await response.json();
        setError(data.error || "AUTHENTICATION FAILED");
        setLoading(false);
        return;
      }

      const result = await response.json();

      setStatus("Verifying Cryptographic Key...");
      await new Promise(r => setTimeout(r, 800));

      setStatus(result.isNew ? "NEW SERVER INITIALIZED" : "CREDENTIALS VERIFIED");
      await new Promise(r => setTimeout(r, 500));

      setStatus("ACCESS GRANTED");
      await new Promise(r => setTimeout(r, 500));

      localStorage.setItem("isAuthenticated", "true");
      localStorage.setItem("serverConfig", JSON.stringify(result.config));
      setLocation("/");
      
    } catch (err) {
      setError("CONNECTION FAILED");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-black flex items-center justify-center p-4 relative overflow-hidden font-mono">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,65,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,65,0.03)_1px,transparent_1px)] bg-[size:30px_30px]" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-8 space-y-2">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border border-primary/30 mb-4 animate-pulse">
            <ShieldCheck className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-display font-bold text-white tracking-widest text-glow">
            EXY ATTACK <span className="text-primary">V3.0</span>
          </h1>
          <p className="text-primary/60 text-xs tracking-[0.2em] uppercase">Secure Command Gateway</p>
        </div>

        <Card className="bg-black/80 border-primary/30 backdrop-blur-xl shadow-[0_0_50px_rgba(0,255,65,0.1)]">
          <CardHeader className="border-b border-primary/10 pb-6">
            <CardTitle className="text-center text-sm font-mono text-primary flex items-center justify-center gap-2">
              <Lock className="w-4 h-4" /> AUTHENTICATION REQUIRED
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 pt-8">
            <form onSubmit={handleLogin} className="space-y-5">
              
              <AnimatePresence mode="wait">
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3 bg-red-500/10 border border-red-500/50 rounded flex items-center gap-2 text-red-500 text-xs font-bold"
                  >
                    <XCircle className="w-4 h-4" /> {error}
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="space-y-2">
                <Label className="text-xs uppercase text-primary/70">Listening Port</Label>
                <div className="relative">
                  <Terminal className="absolute left-3 top-2.5 w-4 h-4 text-primary/50" />
                  <Input 
                    type="number" 
                    placeholder="e.g. 4444" 
                    className="pl-9 bg-black/50 border-primary/20 text-primary focus:border-primary/60 font-mono tracking-widest"
                    value={port}
                    onChange={(e) => setPort(e.target.value)}
                    disabled={loading}
                    required
                    data-testid="input-port"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-xs uppercase text-primary/70">Security Key</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-primary/50" />
                  <Input 
                    type="password" 
                    placeholder="••••••••••••••••" 
                    className="pl-9 bg-black/50 border-primary/20 text-primary focus:border-primary/60 font-mono tracking-widest"
                    value={key}
                    onChange={(e) => setKey(e.target.value)}
                    disabled={loading}
                    required
                    data-testid="input-key"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs uppercase text-primary/70">Domain / IP Address</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-2.5 w-4 h-4 text-primary/50" />
                  <Input 
                    type="text" 
                    placeholder="e.g. c2.domain.com or 192.168.1.1" 
                    className="pl-9 bg-black/50 border-primary/20 text-primary focus:border-primary/60 font-mono tracking-widest"
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    disabled={loading}
                    required
                    data-testid="input-domain"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <Button 
                  type="submit" 
                  className="w-full h-12 bg-primary text-black font-bold tracking-widest hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,255,65,0.4)] transition-all disabled:opacity-70 disabled:cursor-not-allowed"
                  disabled={loading}
                  data-testid="button-login"
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>CONNECTING...</span>
                    </div>
                  ) : (
                    "INITIALIZE SESSION"
                  )}
                </Button>

                {loading && (
                   <div className="text-center space-y-2">
                     <p className="text-[10px] text-primary/70 font-mono animate-pulse">{status}</p>
                     <div className="w-full h-1 bg-primary/10 rounded-full overflow-hidden">
                       <motion.div 
                         className="h-full bg-primary"
                         initial={{ width: "0%" }}
                         animate={{ width: "100%" }}
                         transition={{ duration: 4, ease: "easeInOut" }}
                       />
                     </div>
                   </div>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center">
          <p className="text-[10px] text-primary/30 font-mono">
            UNAUTHORIZED ACCESS IS A FEDERAL OFFENSE
            <br />
            SYSTEM LOGS ARE MONITORED
          </p>
        </div>
      </motion.div>
    </div>
  );
}
