import { useState, useEffect } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Monitor, 
  Smartphone, 
  Server, 
  Terminal, 
  Download, 
  Cpu, 
  Globe, 
  MessageSquare,
  ShieldAlert,
  CheckCircle2,
  AlertOctagon,
  Apple,
  Lock
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import type { ServerConfig } from "@shared/schema";

const OS_OPTIONS = [
  { id: "windows", name: "Windows", icon: Monitor, color: "text-blue-400", border: "hover:border-blue-500/50", ext: ".exe" },
  { id: "linux", name: "Linux", icon: Server, color: "text-orange-400", border: "hover:border-orange-500/50", ext: ".elf" },
  { id: "android", name: "Android", icon: Smartphone, color: "text-green-400", border: "hover:border-green-500/50", ext: ".apk" },
  { id: "ios", name: "iOS", icon: Apple, color: "text-gray-200", border: "hover:border-gray-500/50", ext: ".ipa" },
];

const CONNECTION_TYPES = [
  { id: "external", name: "External Network", desc: "Internet / WAN", icon: Globe },
  { id: "internal", name: "Internal Network", desc: "LAN / VPN", icon: Server },
];

export default function Builder() {
  const [selectedOS, setSelectedOS] = useState<string | null>(null);
  const [connectionType, setConnectionType] = useState<string>("external");
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const [isComplete, setIsComplete] = useState(false);
  const [telegramEnabled, setTelegramEnabled] = useState(false);
  const [persistence, setPersistence] = useState(true);
  const [antiDebug, setAntiDebug] = useState(true);
  const [hideProcess, setHideProcess] = useState(true);

  const { data: config, isLoading: configLoading } = useQuery<ServerConfig | null>({
    queryKey: ["/api/config"],
    queryFn: async () => {
      const res = await fetch("/api/config");
      if (!res.ok) return null;
      return res.json();
    },
  });

  const configReady = config && config.port && config.domain && config.secretKey;

  const startBuild = () => {
    if (!configReady) return;
    if (!selectedOS) return;
    setIsBuilding(true);
    setBuildLogs(["Initializing compiler environment..."]);
    setIsComplete(false);
    setBuildProgress(0);

    const networkMode = connectionType === "external" ? "WAN/Internet" : "LAN/VPN";
    const features = [];
    if (persistence) features.push("PERSISTENCE");
    if (antiDebug) features.push("ANTI-DEBUG");
    if (hideProcess) features.push("STEALTH");
    
    const steps = [
      "Initializing compiler environment...",
      "Loading payload modules...",
      `Setting network mode: ${networkMode}...`,
      `Targeting architecture: ${selectedOS.toUpperCase()}_x64...`,
      `Embedding features: [${features.join(", ")}]...`,
      "Obfuscating core logic...",
      "Embedding C2 configuration...",
      "Applying anti-analysis countermeasures...",
      "Signing binary with spoofed cert...",
      "Compressing and packing payload...",
      "Finalizing build artifact...",
      "Build successful."
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep >= steps.length) {
        clearInterval(interval);
        setIsBuilding(false);
        setIsComplete(true);
        setBuildProgress(100);
        return;
      }
      
      setBuildLogs(prev => [...prev, steps[currentStep]]);
      setBuildProgress(prev => prev + (100 / steps.length));
      currentStep++;
    }, 800);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const c2Domain = config?.domain || "localhost";
    const c2Port = config?.port || 8080;
    const securityKey = config?.secretKey || "default_key";
    const networkMode = connectionType === "external" ? "External (WAN)" : "Internal (LAN)";
    const enabledFeatures = [];
    if (persistence) enabledFeatures.push("Persistence");
    if (antiDebug) enabledFeatures.push("Anti-Debug");
    if (hideProcess) enabledFeatures.push("Hidden");
    
    const fileContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Configurator - ${selectedOS?.toUpperCase()} Service</title>
    <style>
        body { margin: 0; padding: 0; background: #0a0a0a; color: #00ff41; font-family: 'Courier New', monospace; display: flex; align-items: center; justify-content: center; height: 100vh; overflow: hidden; }
        .container { text-align: center; width: 100%; max-width: 500px; padding: 20px; border: 1px solid #333; box-shadow: 0 0 20px rgba(0, 0, 0, 0.5); background: rgba(0,0,0,0.9); border-radius: 8px; }
        .spinner { width: 40px; height: 40px; border: 3px solid rgba(255, 255, 255, 0.1); border-radius: 50%; border-top-color: #00ff41; animation: spin 1s ease-in-out infinite; margin: 20px auto; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .status { margin-top: 20px; font-size: 14px; color: #888; }
        .blink { animation: blink 1s infinite; }
        @keyframes blink { 50% { opacity: 0; } }
        .log-area { text-align: left; background: #111; padding: 10px; font-size: 11px; height: 150px; overflow-y: auto; margin-top: 20px; border: 1px solid #333; color: #aaa; font-family: monospace; }
        .log-entry { margin-bottom: 4px; }
        .success-text { color: #00ff41; }
        .hidden { display: none; }
        .progress-bar { width: 100%; height: 2px; background: #333; margin-top: 10px; position: relative; overflow: hidden; }
        .progress-fill { position: absolute; left: 0; top: 0; height: 100%; background: #00ff41; width: 0%; transition: width 0.5s ease; }
    </style>
</head>
<body>
    <div class="container" id="loader">
        <h3 style="margin: 0; color: #fff;">SYSTEM CONFIGURATION</h3>
        <div class="status" id="main-status">Please wait while Windows configures your system...</div>
        <div class="spinner"></div>
        <div class="progress-bar"><div class="progress-fill" id="fill"></div></div>
        <div class="log-area" id="logs">
            <div class="log-entry">> Initializing configuration wizard...</div>
        </div>
    </div>

    <div class="container hidden" id="connected">
        <h3 style="margin: 0; color: #00ff41;">CONFIGURATION COMPLETE</h3>
        <p style="font-size: 12px; color: #888; margin-top: 10px;">The system has been successfully updated.</p>
        
        <div style="background: #111; padding: 15px; margin-top: 20px; border: 1px solid #333; text-align: left;">
            <div style="font-size: 11px; color: #666; margin-bottom: 5px;">C2 CONNECTION DETAILS:</div>
            <div style="font-size: 12px; color: #00ff41;">> C2 Server: <span style="color: #fff">${c2Domain}:${c2Port}</span></div>
            <div style="font-size: 12px; color: #00ff41;">> Session ID: <span style="color: #fff">ID-${Math.random().toString(36).substring(7).toUpperCase()}</span></div>
            <div style="font-size: 12px; color: #00ff41;">> Auth Key: <span style="color: #fff">${securityKey.substring(0, 4)}****</span></div>
            <div style="font-size: 12px; color: #00ff41;">> Network: <span style="color: #fff">${networkMode}</span></div>
            <div style="font-size: 12px; color: #00ff41;">> Features: <span style="color: #fff">${enabledFeatures.join(" | ") || "None"}</span></div>
            <div style="font-size: 12px; color: #00ff41;">> Status: <span style="color: #fff">Connected to C2</span></div>
            <div style="font-size: 12px; color: #00ff41;">> Mode: <span style="color: #fff">Silent / Hidden</span></div>
        </div>

        <p style="font-size: 11px; color: #666; margin-top: 20px;">Callback: ${c2Domain}:${c2Port}</p>
        
        <button onclick="uninstall()" style="margin-top: 20px; background: #333; border: none; color: #fff; font-size: 10px; cursor: pointer; padding: 8px 16px; border-radius: 4px;">Restart Simulation</button>
    </div>

    <script>
        const C2_CONFIG = {
            domain: "${c2Domain}",
            port: ${c2Port},
            key: "${securityKey}"
        };
        
        const logs = document.getElementById('logs');
        const fill = document.getElementById('fill');
        const mainStatus = document.getElementById('main-status');
        
        function log(text, isSuccess = false) {
            const div = document.createElement('div');
            div.className = 'log-entry';
            if (isSuccess) div.classList.add('success-text');
            div.innerText = '> ' + text;
            logs.appendChild(div);
            logs.scrollTop = logs.scrollHeight;
        }

        const isPersisted = localStorage.getItem('nexus_agent_installed_v2');

        if (isPersisted) {
             document.getElementById('loader').classList.add('hidden');
             document.getElementById('connected').classList.remove('hidden');
        } else {
            let progress = 0;
            
            setTimeout(() => { log("Checking system compatibility..."); fill.style.width = "20%"; }, 1000);
            setTimeout(() => { log("Connecting to C2: " + C2_CONFIG.domain + ":" + C2_CONFIG.port + "..."); fill.style.width = "40%"; }, 2000);
            setTimeout(() => { 
                log("Establishing secure handshake with key..."); 
                fill.style.width = "50%"; 
            }, 3000);
            
            setTimeout(() => { 
                log("Creating hidden background session...", true); 
                fill.style.width = "70%"; 
                mainStatus.innerText = "Connecting to C2 server...";
            }, 4500);

            setTimeout(() => { 
                log("Binding to C2 server: " + C2_CONFIG.domain, true); 
                fill.style.width = "85%"; 
            }, 6000);

            setTimeout(() => { 
                log("Binding service to system version...", true); 
                fill.style.width = "95%"; 
            }, 7500);

            setTimeout(() => { 
                log("Cleaning up installation files...", true); 
                fill.style.width = "100%"; 
                localStorage.setItem('nexus_agent_installed_v2', 'true');
            }, 9000);

            setTimeout(() => {
                document.getElementById('loader').classList.add('hidden');
                document.getElementById('connected').classList.remove('hidden');
            }, 10000);
        }

        function uninstall() {
            localStorage.removeItem('nexus_agent_installed_v2');
            location.reload();
        }
    </script>
</body>
</html>
    `;
    
    const file = new Blob([fileContent], { type: "text/html" });
    element.href = URL.createObjectURL(file);
    element.download = `payload_${selectedOS}_${connectionType}_v2.html`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="PAYLOAD_BUILDER // COMPILER" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-primary/60">
             <Cpu className="w-4 h-4 animate-pulse" />
             <span>BUILD_SERVER: ONLINE</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 pb-20">
          <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Configuration Column */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* OS Selection */}
              <section className="space-y-3">
                <Label className="text-primary text-xs uppercase tracking-widest">1. Select Target Platform</Label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {OS_OPTIONS.map((os) => (
                    <div
                      key={os.id}
                      onClick={() => !isBuilding && setSelectedOS(os.id)}
                      data-testid={`os-${os.id}`}
                      className={cn(
                        "relative cursor-pointer group border border-primary/10 bg-primary/5 p-4 flex flex-col items-center gap-3 transition-all duration-200 hover:bg-primary/10",
                        os.border,
                        selectedOS === os.id && "border-primary bg-primary/10 ring-1 ring-primary shadow-[0_0_15px_rgba(0,255,65,0.2)]",
                        isBuilding && "opacity-50 cursor-not-allowed"
                      )}
                    >
                      <os.icon className={cn("w-8 h-8 transition-transform group-hover:scale-110 duration-300", os.color)} />
                      <span className="text-xs font-bold tracking-wider">{os.name}</span>
                      {selectedOS === os.id && (
                        <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_5px_#00ff41]" />
                      )}
                    </div>
                  ))}
                </div>
              </section>

              {/* Connection Type Selection */}
              <section className="space-y-3">
                <Label className="text-primary text-xs uppercase tracking-widest">2. Network Type</Label>
                <div className="grid grid-cols-2 gap-4">
                  {CONNECTION_TYPES.map((type) => (
                    <div
                      key={type.id}
                      onClick={() => !isBuilding && setConnectionType(type.id)}
                      data-testid={`connection-${type.id}`}
                      className={cn(
                        "relative cursor-pointer group border border-primary/10 bg-primary/5 p-4 flex items-center gap-4 transition-all duration-200 hover:bg-primary/10",
                        connectionType === type.id && "border-primary bg-primary/10 ring-1 ring-primary shadow-[0_0_15px_rgba(0,255,65,0.2)]",
                        isBuilding && "opacity-50 cursor-not-allowed"
                      )}
                    >
                      <div className={cn(
                        "p-3 rounded-lg transition-colors",
                        connectionType === type.id ? "bg-primary/20" : "bg-primary/5"
                      )}>
                        <type.icon className={cn(
                          "w-6 h-6 transition-transform group-hover:scale-110 duration-300",
                          connectionType === type.id ? "text-primary" : "text-primary/60"
                        )} />
                      </div>
                      <div className="flex-1">
                        <span className="text-sm font-bold tracking-wider block">{type.name}</span>
                        <span className="text-[10px] text-muted-foreground">{type.desc}</span>
                      </div>
                      {connectionType === type.id && (
                        <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_5px_#00ff41]" />
                      )}
                    </div>
                  ))}
                </div>
              </section>

              {/* Connection Config */}
              <section className="space-y-4">
                <Label className="text-primary text-xs uppercase tracking-widest">3. Connection Configuration (Locked)</Label>
                <Card className="bg-black/40 border-primary/20">
                  <CardContent className="p-6 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground flex items-center gap-1">
                          <Globe className="w-3 h-3" /> C2 Domain / IP
                        </Label>
                        <div className="relative">
                          <Globe className="absolute left-3 top-2.5 w-4 h-4 text-primary/50" />
                          <Input 
                            value={config?.domain || "Not configured"}
                            readOnly
                            className="pl-9 bg-black/70 border-primary/30 text-primary font-mono text-sm cursor-not-allowed opacity-80"
                            data-testid="input-c2-domain"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground flex items-center gap-1">
                          <Terminal className="w-3 h-3" /> Callback Port
                        </Label>
                        <Input 
                          value={config?.port || "N/A"}
                          readOnly
                          className="bg-black/70 border-primary/30 text-primary font-mono text-sm cursor-not-allowed opacity-80"
                          data-testid="input-callback-port"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground flex items-center gap-1">
                          <Lock className="w-3 h-3" /> Security Key
                        </Label>
                        <Input 
                          type="password"
                          value={config?.secretKey || "••••••••"}
                          readOnly
                          className="bg-black/70 border-primary/30 text-primary font-mono text-sm cursor-not-allowed opacity-80"
                          data-testid="input-security-key"
                        />
                      </div>
                    </div>
                    <p className="text-[10px] text-primary/50 text-center">
                      Configuration locked. Values are set from your authentication session.
                    </p>

                    <div className="flex flex-col gap-3 p-3 border border-primary/10 rounded bg-primary/5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-500/10 rounded">
                            <MessageSquare className="w-4 h-4 text-blue-400" />
                          </div>
                          <div className="space-y-0.5">
                            <Label className="text-sm font-medium">Telegram Reporting</Label>
                            <p className="text-[10px] text-muted-foreground">Send "New Victim" alerts to bot</p>
                          </div>
                        </div>
                        <Switch 
                          checked={telegramEnabled}
                          onCheckedChange={setTelegramEnabled}
                          className="data-[state=checked]:bg-primary" 
                        />
                      </div>
                      
                      <AnimatePresence>
                        {telegramEnabled && (
                          <motion.div 
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="space-y-3 pt-2 border-t border-primary/10 overflow-hidden"
                          >
                             <div className="space-y-1">
                               <Label className="text-[10px] uppercase text-primary/70">Telegram User ID</Label>
                               <Input 
                                 placeholder="@username or ID" 
                                 className="h-8 bg-black/50 border-primary/20 text-xs font-mono"
                               />
                             </div>
                             <div className="space-y-1">
                               <Label className="text-[10px] uppercase text-primary/70">Bot Token</Label>
                               <Input 
                                 type="password"
                                 placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11" 
                                 className="h-8 bg-black/50 border-primary/20 text-xs font-mono"
                               />
                             </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    <div className="flex items-center justify-between p-3 border border-primary/10 rounded bg-primary/5">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-red-500/10 rounded">
                          <ShieldAlert className="w-4 h-4 text-red-400" />
                        </div>
                        <div className="space-y-0.5">
                          <Label className="text-sm font-medium">Anti-Analysis</Label>
                          <p className="text-[10px] text-muted-foreground">Detect VM/Sandbox environments</p>
                        </div>
                      </div>
                      <Switch 
                        checked={antiDebug}
                        onCheckedChange={setAntiDebug}
                        className="data-[state=checked]:bg-primary" 
                        data-testid="switch-anti-debug"
                      />
                    </div>

                    <div className="flex items-center justify-between p-3 border border-primary/10 rounded bg-primary/5">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-purple-500/10 rounded">
                          <Lock className="w-4 h-4 text-purple-400" />
                        </div>
                        <div className="space-y-0.5">
                          <Label className="text-sm font-medium">Persistence</Label>
                          <p className="text-[10px] text-muted-foreground">Survive reboots via autostart</p>
                        </div>
                      </div>
                      <Switch 
                        checked={persistence}
                        onCheckedChange={setPersistence}
                        className="data-[state=checked]:bg-primary" 
                        data-testid="switch-persistence"
                      />
                    </div>

                    <div className="flex items-center justify-between p-3 border border-primary/10 rounded bg-primary/5">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-yellow-500/10 rounded">
                          <Terminal className="w-4 h-4 text-yellow-400" />
                        </div>
                        <div className="space-y-0.5">
                          <Label className="text-sm font-medium">Hidden Process</Label>
                          <p className="text-[10px] text-muted-foreground">Hide from task manager</p>
                        </div>
                      </div>
                      <Switch 
                        checked={hideProcess}
                        onCheckedChange={setHideProcess}
                        className="data-[state=checked]:bg-primary" 
                        data-testid="switch-hide-process"
                      />
                    </div>
                  </CardContent>
                </Card>
              </section>

              {!configReady && !configLoading && (
                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded text-center">
                  <p className="text-red-400 text-sm font-bold">CONFIG NOT FOUND</p>
                  <p className="text-red-400/70 text-xs mt-1">Please login with valid port, key, and domain first.</p>
                </div>
              )}
              
              <Button 
                className="w-full h-12 text-base font-bold tracking-widest bg-primary text-black hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,255,65,0.4)] transition-all"
                disabled={!selectedOS || isBuilding || !configReady}
                onClick={startBuild}
                data-testid="button-build-payload"
              >
                {isBuilding ? "COMPILING..." : configReady ? "BUILD PAYLOAD" : "CONFIG REQUIRED"}
              </Button>

            </div>

            {/* Output Column */}
            <div className="lg:col-span-5 space-y-6">
               <Label className="text-primary text-xs uppercase tracking-widest">4. Build Output</Label>
               
               {/* Terminal */}
               <div className="h-[400px] rounded-lg border border-primary/30 bg-black/80 p-4 font-mono text-xs overflow-hidden flex flex-col relative shadow-[0_0_30px_rgba(0,0,0,0.5)]">
                  <div className="absolute top-0 left-0 w-full h-8 bg-primary/10 border-b border-primary/20 flex items-center px-4 gap-2">
                    <Terminal className="w-3 h-3 text-primary" />
                    <span className="text-primary/70">compiler_log.txt</span>
                  </div>
                  
                  <div className="mt-8 flex-1 overflow-y-auto space-y-2 pb-4 scrollbar-hide">
                    {!selectedOS && (
                      <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50 gap-2">
                        <AlertOctagon className="w-8 h-8" />
                        <span>WAITING FOR CONFIGURATION...</span>
                      </div>
                    )}
                    
                    {buildLogs.map((log, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="text-primary/80 border-l-2 border-primary/30 pl-2"
                      >
                        <span className="text-primary/40 mr-2">[{new Date().toLocaleTimeString()}]</span>
                        {log}
                      </motion.div>
                    ))}
                    
                    {isBuilding && (
                      <motion.div 
                        animate={{ opacity: [0, 1, 0] }} 
                        transition={{ repeat: Infinity, duration: 0.8 }}
                        className="text-primary"
                      >
                        _
                      </motion.div>
                    )}
                  </div>

                  {isBuilding && (
                     <div className="mt-2 space-y-1">
                       <div className="flex justify-between text-[10px] text-primary/60">
                         <span>COMPILING...</span>
                         <span>{Math.round(buildProgress)}%</span>
                       </div>
                       <Progress value={buildProgress} className="h-1 bg-primary/20" />
                     </div>
                  )}
               </div>

               {/* Download Card */}
               <AnimatePresence>
                 {isComplete && (
                   <motion.div
                     initial={{ opacity: 0, y: 20 }}
                     animate={{ opacity: 1, y: 0 }}
                   >
                     <Card className="bg-primary/10 border-primary border-dashed">
                       <CardContent className="p-6 flex flex-col items-center text-center gap-4">
                         <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                           <CheckCircle2 className="w-6 h-6 text-primary" />
                         </div>
                         <div>
                           <h3 className="font-bold text-lg text-primary">Build Successful</h3>
                           <p className="text-sm text-muted-foreground">Client generated: <span className="text-white font-mono">payload_{selectedOS}_{connectionType}_v2.html</span></p>
                           <p className="text-xs text-muted-foreground mt-1">Size: 12 KB | HTML Client Simulation</p>
                         </div>
                         <Button 
                           variant="outline" 
                           className="w-full border-primary/50 text-primary hover:bg-primary hover:text-black gap-2 mt-2"
                           onClick={handleDownload}
                         >
                           <Download className="w-4 h-4" />
                           DOWNLOAD CLIENT
                         </Button>
                       </CardContent>
                     </Card>
                   </motion.div>
                 )}
               </AnimatePresence>

            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
