import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Lock, Skull, AlertTriangle, ShieldAlert, Key } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function Vault() {
  const [isLocked, setIsLocked] = useState(false);

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="VAULT // RANSOMWARE_OPS" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-red-500">
             <Skull className="w-4 h-4 animate-pulse" />
             <span>DANGER ZONE</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 pb-20">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Main Controller */}
            <Card className="bg-red-950/10 border-red-500/30 backdrop-blur-md">
              <CardHeader className="border-b border-red-500/20 pb-4">
                <CardTitle className="text-red-500 flex items-center gap-2">
                  <Lock className="w-5 h-5" /> DEVICE LOCKDOWN PROTOCOL
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="flex items-center justify-between p-4 border border-red-500/20 rounded bg-red-500/5">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-red-500/10 rounded-full">
                      <ShieldAlert className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h3 className="font-bold text-red-400">Full Disk Encryption</h3>
                      <p className="text-xs text-red-400/60">Encrypts all user files (AES-256) and locks bootloader</p>
                    </div>
                  </div>
                  <Switch 
                    checked={isLocked}
                    onCheckedChange={setIsLocked}
                    className="data-[state=checked]:bg-red-500"
                  />
                </div>

                <div className="space-y-4">
                  <Label className="text-red-400 text-xs uppercase tracking-widest">Ransom Note Configuration</Label>
                  <Input 
                    placeholder="YOUR FILES HAVE BEEN ENCRYPTED" 
                    className="bg-black/50 border-red-500/20 text-red-500 focus:border-red-500/50"
                    defaultValue="YOUR FILES ARE ENCRYPTED BY EXY ATTACK"
                  />
                  <Textarea 
                    className="h-32 bg-black/50 border-red-500/20 text-red-500 focus:border-red-500/50 font-mono text-xs"
                    defaultValue={`Attention! All your documents, photos, databases and other important files have been encrypted with a unique key generated for this computer.\n\nTo decrypt your files, you need to pay the ransom in Bitcoin.\n\nPrice: 0.5 BTC\nWallet: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-red-400 text-xs">Payment Address (BTC)</Label>
                    <Input 
                      className="bg-black/50 border-red-500/20 text-red-500 focus:border-red-500/50 font-mono text-xs"
                      placeholder="bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
                    />
                  </div>
                   <div className="space-y-2">
                    <Label className="text-red-400 text-xs">Ransom Amount</Label>
                    <Input 
                      className="bg-black/50 border-red-500/20 text-red-500 focus:border-red-500/50 font-mono text-xs"
                      placeholder="$500 USD"
                    />
                  </div>
                </div>

                <Button 
                  className={cn(
                    "w-full h-12 font-bold tracking-widest transition-all",
                    isLocked 
                      ? "bg-red-500 hover:bg-red-600 text-white shadow-[0_0_20px_rgba(239,68,68,0.4)]" 
                      : "bg-red-950/50 text-red-500/50 border border-red-500/20 hover:bg-red-900/50 hover:text-red-400"
                  )}
                >
                  {isLocked ? "DEPLOY RANSOMWARE PAYLOAD" : "ARM SYSTEM FIRST"}
                </Button>

              </CardContent>
            </Card>

            {/* Status Panel */}
            <div className="grid grid-cols-3 gap-4">
               <Card className="bg-black/40 border-primary/20">
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center gap-2">
                   <Key className="w-6 h-6 text-yellow-500" />
                   <div className="text-2xl font-bold text-white">0</div>
                   <div className="text-[10px] text-muted-foreground uppercase">Keys Generated</div>
                 </CardContent>
               </Card>
               <Card className="bg-black/40 border-primary/20">
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center gap-2">
                   <Lock className="w-6 h-6 text-red-500" />
                   <div className="text-2xl font-bold text-white">0</div>
                   <div className="text-[10px] text-muted-foreground uppercase">Devices Locked</div>
                 </CardContent>
               </Card>
               <Card className="bg-black/40 border-primary/20">
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center gap-2">
                   <AlertTriangle className="w-6 h-6 text-orange-500" />
                   <div className="text-2xl font-bold text-white">$0</div>
                   <div className="text-[10px] text-muted-foreground uppercase">Ransom Paid</div>
                 </CardContent>
               </Card>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
