import { Sidebar } from "@/components/layout/sidebar";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Wifi, 
  Globe, 
  Activity, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShieldCheck,
  Server
} from "lucide-react";

export default function NetworkPage() {
  const connections = [
    { id: "CONN-8842", ip: "192.168.1.105", port: "443", protocol: "HTTPS", status: "ESTABLISHED", latency: "24ms" },
    { id: "CONN-9921", ip: "10.0.0.15", port: "22", protocol: "SSH", status: "LISTENING", latency: "0ms" },
    { id: "CONN-1123", ip: "172.16.5.200", port: "8080", protocol: "HTTP", status: "CLOSE_WAIT", latency: "112ms" },
    { id: "CONN-4451", ip: "192.168.1.50", port: "3389", protocol: "RDP", status: "ESTABLISHED", latency: "45ms" },
    { id: "CONN-7721", ip: "203.0.113.42", port: "443", protocol: "TLSv1.3", status: "SYN_SENT", latency: "89ms" },
  ];

  return (
    <div className="flex h-screen w-full bg-background text-foreground font-mono overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-primary/20 flex items-center justify-between px-6 bg-black/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold tracking-tight">
              <GlitchText text="NETWORK // MONITOR" />
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-primary/60">
            <Activity className="w-4 h-4 animate-pulse" />
            <span>TRAFFIC: NORMAL</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4 flex flex-col gap-2">
                <span className="text-[10px] uppercase text-primary/60">Total Bandwidth</span>
                <div className="flex items-end gap-2">
                  <span className="text-2xl font-bold text-white">1.2</span>
                  <span className="text-xs mb-1 text-primary">GB/s</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4 flex flex-col gap-2">
                <span className="text-[10px] uppercase text-primary/60">Upload</span>
                <div className="flex items-center gap-2 text-green-400">
                  <ArrowUpRight className="w-4 h-4" />
                  <span className="text-xl font-bold">450 MB/s</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4 flex flex-col gap-2">
                <span className="text-[10px] uppercase text-primary/60">Download</span>
                <div className="flex items-center gap-2 text-blue-400">
                  <ArrowDownLeft className="w-4 h-4" />
                  <span className="text-xl font-bold">780 MB/s</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4 flex flex-col gap-2">
                <span className="text-[10px] uppercase text-primary/60">Active Nodes</span>
                <div className="flex items-center gap-2 text-primary">
                  <Server className="w-4 h-4" />
                  <span className="text-xl font-bold">12</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Active Connections */}
          <Card className="bg-black/40 border-primary/30 flex-1">
            <CardHeader className="border-b border-primary/10 py-3">
              <CardTitle className="text-sm font-mono uppercase text-primary flex items-center gap-2">
                <Globe className="w-4 h-4" /> Active Connections
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="grid grid-cols-6 p-3 text-xs text-muted-foreground border-b border-primary/10 bg-primary/5">
                <div className="col-span-1">ID</div>
                <div className="col-span-2">REMOTE ADDRESS</div>
                <div className="col-span-1">PORT</div>
                <div className="col-span-1">PROTOCOL</div>
                <div className="col-span-1 text-right">STATUS</div>
              </div>
              <ScrollArea className="h-[400px]">
                {connections.map((conn) => (
                  <div key={conn.id} className="grid grid-cols-6 p-3 text-xs border-b border-primary/5 hover:bg-primary/5 transition-colors font-mono">
                    <div className="col-span-1 text-primary/70">{conn.id}</div>
                    <div className="col-span-2 text-white">{conn.ip}</div>
                    <div className="col-span-1 text-muted-foreground">{conn.port}</div>
                    <div className="col-span-1 text-muted-foreground">{conn.protocol}</div>
                    <div className="col-span-1 text-right flex justify-end">
                      <Badge variant="outline" className="border-primary/20 text-primary text-[10px] h-5">
                        {conn.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
