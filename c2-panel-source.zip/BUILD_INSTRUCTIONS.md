# دليل بناء تطبيق C2 Panel كـ EXE

## المتطلبات
1. **Node.js** - الإصدار 18 أو أحدث ([تحميل](https://nodejs.org/))
2. **Git** - لنسخ المشروع ([تحميل](https://git-scm.com/))
3. **Windows 10/11** - لبناء ملف exe

## خطوات البناء

### 1. تحميل المشروع
- اضغط على زر "Download as ZIP" من Replit
- فك الضغط عن الملف في مجلد على جهازك

### 2. إنشاء أيقونة Windows
قبل البناء، تحتاج إلى إنشاء ملف أيقونة Windows:
1. افتح الموقع: https://convertio.co/png-ico/
2. ارفع ملف `client/public/favicon.png`
3. حوله إلى `.ico` (اختر حجم 256x256)
4. احفظ الملف كـ `build/icon.ico`

### 3. تثبيت الحزم
افتح Command Prompt أو PowerShell في مجلد المشروع:
```bash
npm install
```

### 4. تثبيت Electron
```bash
npm install --save-dev electron electron-builder
```

### 5. بناء التطبيق
```bash
# بناء الـ frontend و backend
npm run build

# بناء ملف exe
npx electron-builder --win
```

### أو استخدم السكريبت التلقائي
```bash
# شغّل ملف build-windows.bat بالنقر المزدوج عليه
```

### 6. موقع الملفات
بعد البناء، ستجد الملفات في مجلد `release`:
- `C2 Panel-1.0.0-x64.exe` - ملف التثبيت
- `C2 Panel-Portable-1.0.0.exe` - النسخة المحمولة (لا تحتاج تثبيت)

## إعداد قاعدة البيانات

التطبيق يحتاج قاعدة بيانات PostgreSQL للعمل. لديك خيارات:

### الخيار 1: قاعدة بيانات سحابية (مُوصى به)
1. أنشئ حساب مجاني على [Neon](https://neon.tech) أو [Supabase](https://supabase.com)
2. أنشئ قاعدة بيانات جديدة
3. انسخ رابط الاتصال (Connection String)

### الخيار 2: قاعدة بيانات محلية
1. ثبّت [PostgreSQL](https://www.postgresql.org/download/)
2. أنشئ قاعدة بيانات جديدة

### إضافة رابط قاعدة البيانات
أنشئ ملف `.env` في المجلد الرئيسي:
```
DATABASE_URL=postgresql://user:password@host:5432/database
```

ثم شغّل الأمر لإنشاء الجداول:
```bash
npm run db:push
```

## تشغيل في وضع التطوير

```bash
# نافذة 1: تشغيل السيرفر
npm run dev

# نافذة 2: تشغيل Electron
set NODE_ENV=development
npx electron .
```

## هيكل الملفات المهمة
```
├── electron/
│   ├── main.js      # ملف Electron الرئيسي
│   └── preload.js   # ملف الأمان
├── build/
│   └── icon.ico     # أيقونة Windows (يجب إنشاؤها)
├── dist/            # الملفات المبنية
├── client/          # واجهة المستخدم
├── server/          # السيرفر
└── shared/          # الكود المشترك
```

## المشاكل الشائعة

### خطأ: "Cannot find module"
```bash
npm install
npm run build
```

### خطأ في قاعدة البيانات
تأكد من:
1. تعيين متغير `DATABASE_URL` في ملف `.env`
2. تشغيل `npm run db:push` لإنشاء الجداول

### خطأ في Electron
```bash
npm uninstall electron electron-builder
npm install --save-dev electron electron-builder
```

### الأيقونة لا تظهر
تأكد من وجود ملف `build/icon.ico` بالصيغة الصحيحة

## الدعم
- [Electron Documentation](https://www.electronjs.org/docs)
- [Electron Builder](https://www.electron.build/)
- [Drizzle ORM](https://orm.drizzle.team/)
